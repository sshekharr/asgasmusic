<?php
 include "db.php";
session_start();
session_regenerate_id();
 $userid=$_SESSION['userid'];
if(isset($_POST['val'])&&isset($_SESSION['userid']))
   {
	  
	  /*fetching the user notification*/
	   $sql="SELECT * FROM `notification-user` WHERE `user_id`='$userid' AND `status`='unread'";
	   echo'<div class="header_serch_show">Notification</div>';
	 if( $result=mysqli_query($conn,$sql))
	      {
			   if(mysqli_num_rows($result)>0)
				    {
						
						while($show=mysqli_fetch_assoc($result))
						   {
							   echo'<div class="noti_result"><div id="noti'.$show['randomId'].'" class="search_show_inside" style="padding:10px; overflow:auto;">
<p><b><center><h3>'.$show['subject'].'</h3></center></b><br /><b><p>'.$show['notification'].'  
</p></b<div id="close" style="float:right"><button id="close_noti" onClick="close1()">Close</button></div></p>
</div></div>';
						   }
					}
				else
	  {
		  echo '<div class="search_show_inside" style="text-align:center; font-family:playlist;">NO Notification</div>';
	  }	
		  }
		  /*end of the fetching the user notification*/
	
		    
				
			
   }
  if(isset($_POST['val1'])&&isset($_SESSION['userid'])) 
     {
		 /*update the status to read*/
		 echo "status=read";
		 $sql="UPDATE `notification-user` SET `status`='read' WHERE `user_id`='$userid'";
	     $result=mysqli_query($conn,$sql);
		 /*end of the update the status to read*/
	 }
?>