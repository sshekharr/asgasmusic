<?php
sleep(3);
echo "hello";
?>