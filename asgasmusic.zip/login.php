<?php
if(isset($_POST['siusername'])&&isset($_POST['password']))
   {
	   include "db.php";
	   session_start();
	   session_regenerate_id();
	   $pass=mysqli_real_escape_string($conn,$_POST['password']);
	   $euser=mysqli_real_escape_string($conn,strtolower($_POST['siusername']));
	   $salt='A_M';
	   $pass_crypt=sha1(crypt(md5($pass),$salt));
	   $ip=$_SERVER['REMOTE_ADDR'];
	    date_default_timezone_set("Asia/kolkata");
	   $timezone=date_default_timezone_get();
	   $date=date('d/m/y H:i:s a',time());
	   $sql="SELECT * FROM `login-&-signup-data` WHERE `Email`='$euser'";
	   $query=mysqli_query($conn,$sql);
	   $fetch=mysqli_fetch_assoc($query);
	   $count=mysqli_num_rows($query);
	   $browser=$_SERVER['HTTP_USER_AGENT'];
	   if($count>0&&$euser===$fetch['Email']&&$pass_crypt===$fetch['Password']&&$fetch['act-block']==='1'&&$fetch['EmailActivation']=='1')
	      {
			 $name1=$fetch['FirstName']; 
			 $name2=$fetch['LastName']; 
			 $id=$fetch['randomId'];
			 $name=$name1." ".$name2;
			 $sql11="INSERT INTO `user-activities`(`user_id`,`UserName`,`Email`,`Date`,`timezone`,`Ip`,`Browser`) VALUES('$id','$name','$euser','$date','$timezone','$ip','$browser')";
			 $query1=mysqli_query($conn,$sql11);
			 $_SESSION['userid']=$id;
			 echo 1;
			 
		  }
		else if($count>0&&$euser===$fetch['Email']&&$pass_crypt===$fetch['Password']&&$fetch['act-block']==='1'&&$fetch['EmailActivation']=='0')
		   {
			   echo 010;
		   }
		else if($count>0&&$euser===$fetch['Email']&&$pass_crypt===$fetch['Password']&&$fetch['act-block']==='0'&&$fetch['EmailActivation']=='1')   
	           {
	             echo 020;
	           }
	       else
	           {
	              echo 111;
	           }    
   }
    else
     {
         header('location:index.php');
      }
  
?>