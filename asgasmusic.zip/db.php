<?php
$pass="asgasmusic@2016";
$servername="localhost";
$username="asgasmus_all_con";
$conn=mysqli_connect($servername,$username,$pass,"asgasmus_all_content") or die("Error in connection with data base of login user");
?>

