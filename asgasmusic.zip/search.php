<?php
include"db.php";
if(isset($_POST['val']))
    {
		$ser=0;
		$ser1=0;
		$search=mysqli_escape_string($conn,$_POST['val']);
		$sql_search_by_songname="SELECT * FROM `music_name_&_details` WHERE `SongName` LIKE '%$search%'";
		$sql_search_by_moviename="SELECT * FROM `music_name_&_details` WHERE `MovieName` LIKE '%$search%'";
		if($result=mysqli_query($conn,$sql_search_by_songname))
		    {
				if(mysqli_num_rows($result)>0)
				    {
						echo'<div class="header_serch_show">SEARCH BY SONGNAME</div>';
						while($show=mysqli_fetch_assoc($result))
						   {
							   echo'<div class="result"><a href="music show.php?id='.$show['RandomId'].'&Moviename='.$show['MovieName'].'&type='.$show['type'].'"><div id="serch'.$show['id'].'" class="search_show_inside">
<p>'.$show['SongName'].'<br />'.$show['MovieName'].'    '.$show['Duration'].'<br>Amount You Will Earn After Downloading :-₹ '.$show['Amount'].' 
</p>
</div></a></div>';
						   }
					}
					 
				else
				   {
					   $ser=1;
				   }
			}
		
		if($result1=mysqli_query($conn,$sql_search_by_moviename))
		     {
				 if(mysqli_num_rows($result1)>0)
				     {
						 echo'<div class="header_serch_show">SEARCH BY MOVIENAME</div>';
						 while($show1=mysqli_fetch_assoc($result1))
						  {
							  echo'<div class="result"><a href="music show.php?Id='.$show1['RandomId'].'&SongName='.$show1['SongName'].'&movieName='.$show1['MovieName'].'&type='.$show1['type'].'"><div id="" class="search_show_inside">
<p>'.$show1['MovieName'].'<br />'.$show1['SongName'].'    '.$show1['Duration'].'<br>Amount You Will Earn After Downloading :-₹ '.$show1['Amount'].'
</p>
</div></a></div>';
						  }
					 }
				else
				   {
					   $ser1=1;
				   }	 
					 
			 }
	if($ser==1&&$ser1==1)
	     {
			 echo "<center><h1>NOTHING FOUND!!</h1><br><img src='all_icons/unhapp_smily_pTqK9576c.png' width='400' height='400'></center>";
		 }
			
		
	}

?>