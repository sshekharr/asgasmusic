<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>AsgasMedia Download</title>
<link rel="icon" href="all_icons/asgasmusic logo.png" type="png/icon">
</head>
<body>
</body>
</html>
<?php
if(isset($_GET['songId'])&&isset($_GET['songName'])&&isset($_GET['userId']))
     {
		 
		include"db.php"; 
	
	  $userid=$_GET['userId'];	
	  $songid=$_GET['songId'];
	  $songname=$_GET['songName'];
	  $sql="SELECT * FROM `music_name_&_details` WHERE `RandomId`='$songid'";
	  $query=mysqli_query($conn,$sql);
	  $fetch=mysqli_fetch_assoc($query);
	  $address=$fetch['address'];
	  $amount=$fetch['Amount'];
	  $songname__=$fetch['SongName'].'('.$fetch['MovieName'].')';
	  header('Content-disposition: attachment; filename='.$songname__.'.mp3');
	  header('Content-type:audio/mpeg');
	  header('Content-Length: '.filesize($address));
	  readfile($address);
	  // checking the limit of reward
	  $date=date('y-m-d');
      $date_str=strtotime($date);	
	  $sql_user_data_fetch="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	  $query_user_data_fetch=mysqli_query($conn,$sql_user_data_fetch);
	  $fetch_user_data_fetch=mysqli_fetch_assoc($query_user_data_fetch);
	  $name=$fetch_user_data_fetch['FirstName'].' '.$fetch_user_data_fetch['LastName'];
	  $email=$fetch_user_data_fetch['Email'];
	  $phone=$fetch_user_data_fetch['mobileNo'];
	  $sql_limit_check="SELECT * FROM `user-reward-limit` WHERE `email`='$email' AND `date`='$date_str'";
	  $query_limit_check=mysqli_query($conn,$sql_limit_check);
	  $count_limit_check=mysqli_num_rows($query_limit_check);
	  $id= uniqid();
	     
		  if($count_limit_check>0)
		     {
				 $fetch_limit_check=mysqli_fetch_assoc($query_limit_check);
				 $now_limit=($fetch_limit_check['rewardearn']*1);
				 $update_amount=($now_limit*1)+$amount;
				 if($update_amount<5.5)
				    {
                                                      $date=date('y-m-d');
                                                       $date_str_update=strtotime($date);
						$sql_update="UPDATE `user-reward-limit` SET `rewardearn`='$update_amount' WHERE `userid`='$userid' AND `date`='$date_str_update'";
						$query_update=mysqli_query($conn,$sql_update);
						// updating main balance
						$sql_user_bal_update="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	                    $query_user_bal_update=mysqli_query($conn,$sql_user_bal_update);
	                    $fetch_user_bal_update=mysqli_fetch_assoc($query_user_bal_update);
	                    $update_bal=($fetch_user_bal_update['MoneyEarned']*1)+$amount;
	                    $sql_update_bal="UPDATE `login-&-signup-data` SET `MoneyEarned`='$update_bal' WHERE `randomId`='$userid'";
	                    $query_update_bal=mysqli_query($conn,$sql_update_bal);
					}
					
			 }
			else
		     {
				 //creat_limit_rec
				 $sql_insert="INSERT INTO `user-reward-limit`(`randomId`, `userid`, `name`, `email`, `phone`, `rewardearn`, `date`) VALUES ('$id','$userid','$name','$email','$phone','$amount','$date_str')";
				 $query_insert=mysqli_query($conn,$sql_insert);
				 // updating main balance
				$sql_user_bal_update="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	            $query_user_bal_update=mysqli_query($conn,$sql_user_bal_update);
	            $fetch_user_bal_update=mysqli_fetch_assoc($query_user_bal_update);
	            $update_bal=($fetch_user_bal_update['MoneyEarned']*1)+$amount;
	            $sql_update_bal="UPDATE `login-&-signup-data` SET `MoneyEarned`='$update_bal' WHERE `randomId`='$userid'";
	            $query_update_bal=mysqli_query($conn,$sql_update_bal);
			 } 
	  
	  
	  
	  
	 }
else{
	   header("location:index.php");
	}	 
?>