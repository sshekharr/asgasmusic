<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>AsgasMedia Download</title>
<link rel="icon" href="all_icons/asgasmusic logo.png" type="png/icon">
</head>
<body>
</body>
</html>
<?php
if(isset($_GET['songid'])&&isset($_GET['songname']))
  {
	  
	  include"db.php"; 
	  $songid=$_GET['songid'];
	  $songname=$_GET['songname'];
	  $sql="SELECT * FROM `music_name_&_details` WHERE `RandomId`='$songid'";
	  $query=mysqli_query($conn,$sql);
	  $fetch=mysqli_fetch_assoc($query);
	  $address=$fetch['address'];
	  $songname__=$fetch['SongName'].'('.$fetch['MovieName'].')';
	  header('Content-disposition: attachment; filename='.$songname__.'.mp3');
	  header('Content-type:audio/mpeg');
	  header('Content-Length: '.filesize($address));
	  readfile($address);
	  echo "<script>window.close();</script>";
	  
  }
  if(isset($_GET['songId'])&&isset($_GET['songName'])&&isset($_GET['userId']))
     {
		 sleep(5);
		include"db.php"; 
	  $userid=$_GET['userId'];	
	  $songid=$_GET['songId'];
	  $songname=$_GET['songName'];
	  $sql="SELECT * FROM `music_name_&_details` WHERE `RandomId`='$songid'";
	  $query=mysqli_query($conn,$sql);
	  $fetch=mysqli_fetch_assoc($query);
	  $address=$fetch['address'];
	  $amount=$fetch['Amount'];
	  $songname__=$fetch['SongName'].'('.$fetch['MovieName'].')';
	  header('Content-disposition: attachment; filename='.$songname__.'.mp3');
	  header('Content-type:audio/mpeg');
	  header('Content-Length: '.filesize($address));
	  readfile($address);
	  $sql_user_bal_update="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	  $query_user_bal_update=mysqli_query($conn,$sql_user_bal_update);
	  $fetch_user_bal_update=mysqli_fetch_assoc($query_user_bal_update);
	  $update_bal=($fetch_user_bal_update['MoneyEarned']*1)+$amount;
	  $sql_update_bal="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	  $query_update_bal=mysqli_query($conn,$sql_update_bal);
	 
	  
	  
	  
	  
	 }
  else
  {
	  header('location:index.php');
  }
?>