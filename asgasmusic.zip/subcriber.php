<?php
if(isset($_POST['subemail'])&&isset($_POST['userid']))
  {  
     include"db.php";
	 $subemail=mysqli_real_escape_string($conn,$_POST['subemail']);
	 $userid=mysqli_real_escape_string($conn,$_POST['userid']);
	 $ip=$_SERVER['REMOTE_ADDR'];
	 $id=uniqid();
	 $sql="INSERT INTO `subcriber`(`randomid`, `ip`, `email`,`userid`) VALUES ('$id','$ip','$subemail','$userid')";
	 if($query=mysqli_query($conn,$sql))
	    {
			echo 100;
		}
	 else
	 {
		 echo 110;
	 }
  }
 else
    {
		echo 111;
	}
?>