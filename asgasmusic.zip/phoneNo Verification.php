<?php
include"db.php";
if(isset($_POST['mob']))
    {
		$mob=$_POST['mob'];
		   
				$sql="SELECT * FROM `login-&-signup-data` WHERE `mobileNo`='$mob'";
				$query=mysqli_query($conn,$sql);
				$count=mysqli_num_rows($query);
				if($count==0)
				  echo 000;
				else
				  echo 111;  
				
				
	}
?>