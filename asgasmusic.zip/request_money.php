<?php
include "db.php";
session_start();
session_regenerate_id();
sleep(3);
if(isset($_POST['recharge_opt'])&&isset($_POST['amount'])&&isset($_POST['wallet_amount'])&&isset($_POST['redeeming_amt'])&&isset($_POST['total'])&&isset($_POST['userid']))
   {
	   $recharge_opt=$_POST['recharge_opt'];
	   $amount=$_POST['amount'];
	   $wallet_amt=($_POST['wallet_amount']*1);
	   $redeeming_amt=$_POST['redeeming_amt'];
	   $total=$_POST['total'];
	   $redeeming_amt_veri=($amount*0.05)+$amount;
	   $userid=$_POST['userid'];
	   $sql="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	   $query=mysqli_query($conn,$sql);
	   if(mysqli_num_rows($query)>0)
	       {
			   $result=mysqli_fetch_assoc($query);
			   if(isset($_POST['recharge_opt'])&&isset($_SESSION['userid'])&&isset($_SESSION['MoneyEarned'])&&$redeeming_amt==$redeeming_amt_veri&&$result['MoneyEarned']==$wallet_amt&&$result['randomId']==$_POST['userid'])
			   {
				   $total_veri=$result['MoneyEarned']-$redeeming_amt;
				    if($total==$total_veri)
					   {
						   date_default_timezone_set("Asia/kolkata");
	                       $timezone=date_default_timezone_get();
	                       $date=date('d/m/y H:i:s a',time());
						   $txtid=sha1(md5(time()));
						   $Ip=$_SERVER['REMOTE_ADDR'];
						   $status='pending';
						   $name=$result['FirstName']." ".$result['LastName'];
						   $email=$result['Email'];
						  $sql_update_money="UPDATE `login-&-signup-data` SET `MoneyEarned`='$total_veri' WHERE `randomId`='$userid'";
						  $query_updqt_money=mysqli_query($conn,$sql_update_money);
						  $sql_update_money_request="INSERT INTO `money-request`(`user_id`, `Name`, `Email`, `txt_id`, `amount`, `recharge_opt`, `status`, `date`, `ip`) VALUES ('$userid','$name','$email','$txtid','$amount','$recharge_opt','$status','$date','$Ip')";
						  if($sql_update_money_request=mysqli_query($conn,$sql_update_money_request))
						     {
								
						       if($recharge_opt=='Paytm')
							      {
									  echo 111;
								  }
								if($recharge_opt=='Recharge')
							      {
									  echo 000;
								  }  
							   
							 }
					   }
			   }
		   }
   }
?>
