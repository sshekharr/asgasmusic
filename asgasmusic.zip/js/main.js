// JavaScript Document
function redem()
   { //onloade redeem amount
	   $( "#amount" ).selectmenu();
	   $( "#recharge_opt" ).selectmenu();
	  var amount= $("#money").attr("val");
	  var need=52.5-amount;
	  $("#statu").html("You Need '"+need+"' More For Redeem.");
	   }
    
  
  
		
	setInterval(function(){
		    $.ajax({
		    type:'POST',
			url:"check_subscriber.php",
			data:{userid:userid},
			success: function(msg){
				    if(msg==100)
					   {
						   $("#subscribe").empty();
						   $("#subscribe").html('<img src="all_icons/subscribe-min.png" class="sub_style"><center><p style="font-family:playlist; font-size:16px; color:#000; margin-top:13%; " >SubscribeUs For More Latest Update In Our Website.</p><br /><div id="subscribe_btn1" class="sub_btn  ui-state-disabled">Subscribed</div></center>');
						   console.log(msg);
					   }
					  if(msg==000)
					    {
							$("#subscribe").empty();
							$("#subscribe").html('<img src="all_icons/subscribe-min.png" class="sub_style"><center><p style="font-family:playlist; font-size:16px; color:#000; margin-top:13%; " >SubscribeUs For More Latest Update In Our Website.</p><br /><input type="text" placeholder="Email" id="subscribe_email" class="form-control" style="width:60%; background:url(all_icons/email-min.png) no-repeat #FFF; padding-left:45px; padding-top:2px; line-height:34px;"/><div id="subscribe_btn" class="sub_btn">SubscribeUs</div></center>');
						}
				   
				}
			
		});
		
		},30000); 
	$("#subscribe_btn").on("click",function(e) {
        var subcriber=$("#subscribe_email").val();
		var islogin=$("#islogin").attr("status").split(" ");
		
	 if(islogin[0]=='<br')
		   {
			   toastr.error("First Login In Your Account");
			   $("#signin").modal();
			   
		   }
	else if(subcriber==""||subcriber.length==0||$.trim(subcriber).length==0)
		    {
				toastr.error("Please Enter Your Email Address");
			}	   
			   
		else{
			   
		   
			    $.ajax({
				    data:{subemail:subcriber,userid:userid},
					type:'POST',
					url:"subcriber.php",
					success: function(msg){
						   if(msg==100)
						      {
								  toastr.success("Thank You For subscribing Us. Now You Will Get Our Latest Update.");
								  $("#subscribe").empty();
						   $("#subscribe").html('<img src="all_icons/subscribe-min.png" class="sub_style"><center><p style="font-family:playlist; font-size:16px; color:#CCC; margin-top:13%; " >SubscribeUs For More Latest Update In Our Website.</p><br /><div id="subscribe_btn1" class="sub_btn  ui-state-disabled">Subscribed</div></center>');
							  }
							if(msg==110)
							  {
								   toastr.error("Unable To Update Our DataBase Please Retry After Sometime.");
							  }
							if(msg==111)
							  {
								   toastr.error("Something Went Wrong!!");
							  }
						}
				});
				
		}
    }); 
  

$(document).ready(function(e) {
	$("#Forgottenaccountpass").click(function(){
		$("#passreset_request").modal();
	});
	$("#music").click(function(){
		var show=$("#music-content").attr("show");
		if(show=='none')
			{
				$(".icon-right").removeClass("fa");
				$(".icon-right").removeClass("fa-chevron-circle-down");
				$(".icon-right").addClass("fa");
				$(".icon-right").addClass("fa-chevron-circle-up");
				$("#music-content").css("display","block");
				$("#music-content").attr("show","display");
			}
		else
			{
				$(".icon-right").removeClass("fa");
				$(".icon-right").removeClass("fa-chevron-circle-up");
				$(".icon-right").addClass("fa");
				$(".icon-right").addClass("fa-chevron-circle-down");
				$("#music-content").css("display","none");
				$("#music-content").attr("show","none");
			}
	});
   setInterval(function(){
	   var width=window.innerWidth;
	if(width<=1560 && width>1390)
		{
			$(".bollywood_latest_song").css("width",66+"%");
			$(".song").css("margin-left",1.5+"%");
			$(".tab-login-div").css("display","none");
			$("#ads300x250").css("display","block");
		}
	   
	  else if(width<=1389 && width>1250)
		{
			$(".bollywood_latest_song").css("width",66+"%");
			$(".song").css("margin-left",12+"%");
			$(".tab-login-div").css("display","none");
			$("#ads300x250").css("display","block");
		}
	  else if(width<=1250 && width>1050)
		{
			$(".bollywood_latest_song").css("width",66+"%");
			$(".song").css("margin-left",8+"%");
			$(".tab-login-div").css("display","none");
			$("#ads300x250").css("display","block");		   
			   $("#ads300x250").css("margin-left","2px");
			   $(".dur").css("margin-right","2px");
		   
		}
	   
	else if(width>1560)
		 {
			 $(".bollywood_latest_song").css("width",60+"%");
			 $(".song").css("margin-left",3+"%");
			 $(".tab-login-div").css("display","none");
			 $("#ads300x250").css("display","block");
		 }
	  
   },250); 
    
	
	$(".hover").hover(function(){
	   $(this).attr("class","animated infinite rubberBand");
	   $(this).css("color","#F90");
	 },function(){
		 $(this).removeClass("animated infinite rubberBand ");
		 $(this).attr("class","hover");
		 $(this).css("color","#fff");
		 }); 
		 $("#Forgottenaccountpass").click(function(e) {
            $("#passreset_request").modal();
        });
	
	$("#recoverpassemail").focusout(function(e) {
        var recover_email=$(this).val();
		if(recover_email.length==0||recover_email==""||$.trim(recover_email).length==0)
		   {
			   toastr.error("Please Enter The Valid Email!!");
		   }
		   else
		    {
				
				 $.ajax({
					 type:'POST',url:"email validation.php",data:{email:recover_email},
					 success: function(msg){
						     if(msg==000)
							    {
									$("#recoverpassemail").attr("class","none");
				                    $("#recoverpassemail").attr("class","error");
									$("#recoverpassemail").attr("class","form-control");
				                    $("#passrecover").css("display","none");
									 console.log(msg);
									
									
								}
							 if(msg==111)
							    {
									$("#recoverpassemail").attr("class","none");
									$("#recoverpassemail").attr("class","form-control");
									toastr.success("Email Id Found In Our Database");
									var k = Math.floor(Math.random()* 1000000);
				                     $.cookie("email_recover",k,{psth:"/"});
									toastr.options={"positionClass": "toast-bottom-right"};
									$("#passrecover").css("display","block");
									console.log(msg);

								}
							 if(msg==222)
							    {
									$("#recoverpassemail").attr("class","none");
				                    $("#recoverpassemail").attr("class","error");
									$("#recoverpassemail").attr("class","form-control");
									toastr.error("Please Enter The Valid Email Id");
									toastr.options={"positionClass": "toast-bottom-right"};
									$("#passrecover").css("display","none");
									console.log(msg);
								}	
						 }
					 });
			}
    });
	$("#passrecover").click(function(e) {
		var cookie=$.cookie("email_recover");
		var email=$("#recoverpassemail").val();
		   if(cookie)
		     {
				 $("#working_recover_email").css("display","block");
				 $(this).css("display","none");
				 $.ajax({
					    type:'POST',url:"password_request.php",
						data:{email:email},
						success: function(msg){
							if(msg==100)
							    {
									toastr.success("Link has been sent in your registered email id");
									$(this).css("display","none");
									$.modal.close();
									
									
								}
							 if(msg==010)
							    {
									toastr.error("Error in sending mail.");
									$("#feedback_admin").modal();
									toastr.success("Write Us What Problem You Are Facing");
                                                                        $(this).css("display","none"); 
									
								}
							else
							   {
								   toastr.error("Something Went Wrong");
								   console.log(msg);
                                                                   $(this).css("display","none");
							   }
								
							     
							}
					 
					 });
				 
			 }
		  else
		    {
				toastr.error("Please Enter The Valid Email!!");
				
			}
        
    });
  	   

	$("#update_feedback").click(function(){
		var islogin=$("#islogin").attr("status").split(" ");
		if(islogin[0]=='<br')
		   {
			   toastr.error("First Login In Your Account");
			   $("#signin").modal();
			   
		   }
		   else{
		    var opt=$("#feedback_data").val();
			var msg=$("#comment").val();
			if(opt=='null'||msg==""||msg.length==0||$.trim(msg).length==0)
			   {
				    toastr.error("Field Cannot Be Empty");
			   }
			 else
			    {
					$.ajax({
						     type:'POST',
							 url:"feedback.php",
							 data:{opt:opt,msg:msg,userid:userid},
							 beforeSend: function(){
								  $("#feedback_loading").css("display","block");
								  $("#update_feedback").css("display","none");   
								 },
							 success: function(msg){
								      $("#feedback_sucess").css("display","block");
									  $("#feedback_loading").css("display","none");
								 }
						
						});
				}
		   }
		});
        
		
		
   
	setInterval(function(){
		
		  wid=window.innerWidth;
		  if(wid<=1280)
		     {
				$("#ads728x90").css("margin-left","30%"); 
				
			 }
		  else
		     {
				$("#ads728x90").css("margin-left","33%");
				
			 }
		  
		},1000);
    $("#logo").click(function(){
		window.location.href="index.php";
		});
	$("#music").click(function() {
        $("#holly_bolly").modal();
    });	
	$("#bolly_icon").click(function(e) {
        window.location.href="music.php";
    });
	$("#holly_icon").click(function(e) {
        window.location.href="music Hollywood.php";
    });
	

	$("#home").click(function(){window.location.href="index.php";});
	$("#fb").click(function(){
		
		window.location.href="https://www.facebook.com/Asgasmusic-1253884004688389/";
	});
	$("#fb").hover(function(){
		   $(".socialfb").css('width','80');
		   $(".socialfb").css('height','80');
		   $(".fbicon").css('width','80');
		   $(".fbicon").css('height','80');
		   $(".fbicon").attr("src","all_icons/fb_hover.png");
		   
		   
		},function(){
			$(".socialfb").css('width','70px');
		   $(".socialfb").css('height','70px');
		   $(".fbicon").css('width','70px');
		   $(".fbicon").css('height','70px');
		   $(".fbicon").attr("src","all_icons/facebook_circle_color-512.png");
			});
	$("#twitter").click(function(){
		
		window.location.href="https://twitter.com/musicasgas";
	});
	$("#twitter").hover(function(){
		   $(".socialtw").css('width','80');
		   $(".socialtw").css('height','80');
		   $(".twicon").css('width','80');
		   $(".twicon").css('height','80');
		   $(".twicon").attr("src","all_icons/twitter_hover.png");
		   
		},function(){
		$(".socialtw").css('width','70px');
		   $(".socialtw").css('height','70px');
		   $(".twicon").css('width','70px');
		   $(".twicon").css('height','70px');
		   $(".twicon").attr("src","all_icons/twitter_circle_color-256.png");
			});		
	$("#whatsapp").hover(function(){
		   $(".socialwa").css('width','80');
		   $(".socialwa").css('height','80');
		   $(".waicon").css('width','80');
		   $(".waicon").css('height','80');
		   $(".waicon").attr("src","all_icons/wa_hover.png");
		   
		   
		},function(){
			$(".socialwa").css('width','70px');
		   $(".socialwa").css('height','70px');
		   $(".waicon").css('width','70px');
		   $(".waicon").css('height','70px');
		   $(".waicon").attr("src","all_icons/whatsapp.png");
			});		
		
		
			
		    
			$("#signin_email").focusout(function(){check_user();});
			$("#signin_pass").focusout(function(){check_pass();});
			function check_user()
			 {
				 var siusername=$("#signin_email").val();
				 if($.trim(siusername).length==0||siusername==""||siusername.length==0)
				     {
						 
						  $(".input").addClass("error");
					 }
				else
				   {
					   
						  $("#signin_email").attr("class","normal");
						  $.cookie("_mail",siusername,{path:'/'});
				   }
			 }
			function check_pass()
			 {
				var password=$("#signin_pass").val();
				 if($.trim(password).length==0||password==""||password.length==0)
				     {
						 
						  $("#signin_pass").addClass("error");
					 }
				else
				   {
						  $("#signin_pass").attr("class","normal");
						  $.cookie("_pass",Math.round(Math.random()*10000000000000000000),{path:'/'});
				   }
			 } 
			 			$("#signin_pc").click(function(){
				var password=$("#signin_passpc").val();
				var siusername=$("#signin_emailpc").val();
				var cuser=$.cookie("_mail");
				var cpass=$.cookie("_pass");
				   
						   $("#bttn").empty();
						   $("#siloading").css("display","block");
						   $.ajax({
							   type:'POST',
							   url:"login.php",
							   data:{siusername:siusername,password:password},
							   success: function(msg_login)
							      {
									  if(msg_login==1)
									  {
										 console.log(msg_login);
										 console.log("hello");
										 window.location.reload();
                                         $.removeCookie("_mail",{path:'/'});
                                         $.removeCookie("_pass",{path:'/'});
									  }
									 if(msg_login==111)
									   {
										   console.log(msg_login);
										   toastr.error("Please Enter The Valid Email And Password!!");
										   
									   }
									   if(msg_login==010)
									   {
									             console.log(msg_login);
										   toastr.error("Please Active Your Account And logging Again!!");
										   
									   }
									    if(msg_login==020)
									   {
									             console.log(msg_login);
										   toastr.error("Account has been locked. Please contact your administrator !!");
										   
									   }
								  }
							
							   });
					   
				});
			$("#signin_1").click(function(){
				var password=$("#signin_pass").val();
				var siusername=$("#signin_email").val();
				var cuser=$.cookie("_mail");
				var cpass=$.cookie("_pass");
				   
						   $("#bttn").empty();
						   $("#siloading").css("display","block");
						   $.ajax({
							   type:'POST',
							   url:"login.php",
							   data:{siusername:siusername,password:password},
							   success: function(msg_login)
							      {
									  if(msg_login==1)
									  {
										 console.log(msg_login);
										 console.log("hello");
										 window.location.reload();
                                         $.removeCookie("_mail",{path:'/'});
                                         $.removeCookie("_pass",{path:'/'});
									  }
									 if(msg_login==111)
									   {
										   console.log(msg_login);
										   toastr.error("Please Enter The Valid Email And Password!!");
										   
									   }
									   if(msg_login==010)
									   {
									             console.log(msg_login);
										   toastr.error("Please Active Your Account And logging Again!!");
										   
									   }
									    if(msg_login==020)
									   {
									             console.log(msg_login);
										   toastr.error("Account has been locked. Please contact your administrator !!");
										   
									   }
								  }
							
							   });
					   
				});
		$("#setting").click(function(e) {
            $("#setting_menu").modal();
        });		
						
});
 
function change_pass(){
   $("#show_data").css("display","none");
   $("#chng_pass").css("display","block");
}
function back00(){
   $("#show_data").css("display","block");
   $("#chng_pass").css("display","none");
}
function curr()
   {
	   var pass=$("#cpass").val();
	   if($.trim(pass).length==0||pass.length==0||pass==""||pass.length<=6)
	       {
			        $("#cpass").attr("class","none");
					$("#cpass").attr("class","error"); 
					toastr.error("PassWord Must Be Greater Than 6");
					toastr.options={"positionClass": "toast-bottom-right"};
					$("#update").css("display","none");
		   }
		else
				  {
					  $("#cpass").attr("class","none");
					$("#cpass").attr("class","correct");
					$.cookie("cpassword",pass,{path:"/"});
					$("#update").css("display","block");
					 
				  }   
   }
 function newp()
   {
	   var npass=$("#npass").val();
	   var cpass=$("#cpass").val();
	   if($.trim(npass).length==0||npass.length==0||npass==""||npass.length<=6)
	       {
			        $("#npass").attr("class","none");
					$("#npass").attr("class","error"); 
					toastr.error("PassWord Must Be Greater Than 6");
					toastr.options={"positionClass": "toast-bottom-right"};
					$("#update").css("display","none");
		   }
		   else if(cpass==npass)
		       {
				    $("#npass").attr("class","none");
					$("#npass").attr("class","error"); 
					toastr.error("Current Password And New Password Not Be Same.");
					toastr.options={"positionClass": "toast-bottom-right"};
					$("#update").css("display","none");  
			   }
		else
				  {
					$("#npass").attr("class","none");
					$("#npass").attr("class","correct");
					$.cookie("password",npass,{path:"/"});
					$("#update").css("display","block");
					 
				  }   
   }
 function renew()
   {
	   var pass=$("#npass").val();
	   var repass=$("#cnpass").val();
	   var repass_len=repass.length;
	   if(repass!==pass)
			      {
					$("#cnpass").attr("class","none");
					$("#cnpass").attr("class","error"); 
					toastr.error("Please Type The Valid PassWord");
					toastr.options={"positionClass": "toast-bottom-right"};
					$("#update").css("display","none");
					
				  }
				else
				  {
					$("#cnpass").attr("class","none");
					$("#cnpass").attr("class","correct");
					$.cookie("repassword",repass,{path:"/"});
					$("#update").css("display","block");
					  
				  }
   }
  
  function newpass(){
	  var pass=$.cookie("cpassword");
	  var npass=$.cookie("password");
	  var renpass=$.cookie("repassword");
	  if(pass&&npass&&renpass)
	     {
			$.ajax({
				    type:'POST',
					url:"update_pass.php",
					data:{pass:pass,npass:npass,renpass:renpass},
					beforeSend: function(){
						    
							$("#fetch_pass").css("display","block");},
				 success: function(msg){
					 $("#fetch_pass").css("display","none");
					        if(msg==000) 
							   {
								   alert("Password Updated!!");
								   window.location.replace("logout.php");
								   $.removeCookie("cpassword",{path:'/'});
								   $.removeCookie("password",{path:'/'});
								   $.removeCookie("repassword",{path:'/'});
							   }
							 if(msg==111) 
							   {
								   alert("Password Does Not Updated!!");
								   window.location.href.reload();
								   $.removeCookie("cpassword",{path:'/'});
								   $.removeCookie("password",{path:'/'});
								   $.removeCookie("repassword",{path:'/'});
							   }  
					 
					 }
				 });
		 }
				console.log(window.innerWidth);
				
		 
  }