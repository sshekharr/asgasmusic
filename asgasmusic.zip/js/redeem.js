// JavaScript Document
$(document).ready(function(e) {
    $("#redeem").click(function(){
		//amount redeeming
		   $("#redeem_money").modal();
		    
		     $.ajax({
				    type:'POST',
					url:"pending request.php",
					data:{a:1},
					beforeSend: function(){
						    
							$("#fetch").css("display","block");},
				 success: function(msg){
					        $("#show_pending_request").html(msg);
					 
					 }
				 });
		   		});
	$(".redeem-pc").click(function(){
		//amount redeeming
		   $("#redeem_money").modal();
		    
		     $.ajax({
				    type:'POST',
					url:"pending request.php",
					data:{a:1},
					beforeSend: function(){
						    
							$("#fetch").css("display","block");},
				 success: function(msg){
					        $("#show_pending_request").html(msg);
					 
					 }
				 });
		   		});
});
   
  function redem_now(){
     var recharge_opt=$("#recharge_opt").val();
	 var amount=$("#amount").val();
	 var wallet_amount=$("#money").attr("val");
	 var redeeming_amt=((amount*1)+(amount*0.05));
	 var total=(wallet_amount-redeeming_amt)
	 if(wallet_amount>=redeeming_amt)
	     {
			$("#details").empty();
			$("#details").html('<center><div id="wallet_amount" style="font-size:20px; font-family:playlist; padding-left:1%;">'+wallet_amount+'(Wallet Balance) - '+redeeming_amt+' (Redeeming Amount)= '+total+'</div><div id="show_remaining_bal">Remaining Balance:-'+total+'</div><br /><button id="redeem_now" class="ui-button" onclick="redeeming_amount()">Redeem Now</button><div id="loader" class="loader"></div></center>');
			$("#back").html('<br><button id="back" class="ui-button" onclick="reload1()">Back</button>');
			$.cookie("recharge_opt",recharge_opt,{path:"/"});
			$.cookie("amount",amount,{path:"/"});
			$.cookie("wallet_amount",wallet_amount,{path:"/"});
			$.cookie("redeeming_amt",redeeming_amt,{path:"/"});
			$.cookie("total",total,{path:"/"});
			
	  }
	  else
	  {
		      
		     $("#details").empty();
			 $("#details").html('<center><h4 style="font-size:20px; font-family:playlist;">Redeem Cannot Proceed.</h4><br><button id="redeem_now" class="ui-button" onclick="redeeming_amount()">Redeem Now</button><br><div id="loader" class="loader"></div></center>');
			 $("#details").attr("class","ui-state-disabled");
			 $("#back").html('<br><button id="back" class="ui-button" onclick="reload1()">Back</button>');
			 
	  }
	 
  }
 function reload1(){
 window.location.reload();
 }
function redeeming_amount(){
     var recharge_opt=$.cookie("recharge_opt");
	 var amount=$.cookie("amount");
	 var wallet_amount=$.cookie("wallet_amount");
	 var redeeming_amt=$.cookie("redeeming_amt");
	 var total=$.cookie("total");
		$.ajax({
		 type:'POST',url:"request_money.php",
		  data:{recharge_opt:recharge_opt,wallet_amount:wallet_amount,redeeming_amt:redeeming_amt,total:total,amount:amount,userid:userid},
	      beforeSend: function(){
							      $("#loader").css("display","block");
								  $("#back").attr("class","ui-state-disabled");  
							},
		
		 success: function(msg)
		     {
				 $("#redeem_money").empty();
				 if(msg==111)
				   {
				 $("#redeem_money").html('<img src="all_icons/paytm-min.png" style="width:100%; min-width:500px; min-height:500px; height:100%" /><br><div id="back"></div>');
				 console.log(msg);
				   }
				 else if(msg==000)
				     {
						$("#redeem_money").html('<img src="all_icons/recharge-min.png" style="width:100%; min-width:500px; min-height:500px; height:100%" /><br><div id="back"></div>');
				 console.log(msg);
					 }
					 $("#back").html('<br><button id="back" class="ui-button" onclick="reload1()">Back</button>');
			 }
		 
		 
		 }); 
	 
}
function request(){
	
	alert("hello");
	}
  