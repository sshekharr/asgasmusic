// JavaScript Document
setInterval(function(){
     var modal=$("#earn_ads_show").css("display");
           $.cookie("modal",modal,{path:'/'});

},1000);
          
           
              
          

             
$(document).ready(function(e) {
var isActive
window.onfocus = function () {
     isActive = 'focuse';
    console.log(isActive);
 };

window.onblur = function () {
    isActive = 'infocuse';
  console.log(isActive);
    
 };
setInterval(function(){
     var ismodalopen=$.cookie("modal");
     if(ismodalopen=='inline-block'&&isActive=='infocuse')
         {
			 
          var songid1=$.cookie("songid");
		var songname1=$.cookie("songname");
                var userid_ads1=$.cookie("userid_ads");
                var count_ads1=$.cookie("count_ads");
                var date_ads1=$.cookie("date_ads");
			 $.ajax({
				 type:'post',
				 url:'Shownads_count.php',
				 data:{userid:userid_ads1,count:count_ads1,date:date_ads1},
				 success:function(msg){
					 
				 }
			 });
         window.open('songdownload earn.php?songId='+songid1+'&songName='+songname1+'&userId='+islogin);
		$.removeCookie("songid",{path:"/"});
		$.removeCookie("songname",{path:"/"});
                $.removeCookie("userid_ads",{path:"/"});
		$.removeCookie("count_ads",{path:"/"});
                $.removeCookie("date_ads",{path:"/"});
		var width= window.innerWidth;
			 if(width<=1000)
				 {
					 var show="your download will start in a few seconds";
					 alert(show.toUpperCase());
					 
				 }
		$.modal.close();
		setTimeout(function(){location.reload();}, 3000);
		
}

},1000);
    var islogin=$("#islogin").attr("status").split(" ");  
		  if(islogin[0]=='<br')
		  {
			 $("").insertAfter("body");
			 			 
		  }
		  $(".shadow00").click(function(){
			var songname=$(this).attr("downloadsongname");				 				 
	        var songid=$(this).attr("downloadsongid");
			$.cookie("songname",songname,{path:"/"});	
			$.cookie("songid",songid,{path:"/"});
			
			var songname	 
		  if(islogin[0]=='<br'){
			  window.open('songdownload.php?songid='+songid+'&songname='+songname);
			  }
		 else
		   {
			   $("#earn_ads_show").modal();
			   
                                
                              
		   }
				 });
       
			 
	
	$("#nonereward").click(function(e) {
       var songid1=$.cookie("songid");
		var songname1=$.cookie("songname"); 
		window.open('songdownload.php?songid='+songid1+'&songname='+songname1);
		$.modal.close();
    });		
});
// JavaScript Document