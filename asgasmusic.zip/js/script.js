// JavaScript Document
function checkPopup() {
  var openWin = window.open("http://www.google.com","directories=no,height=100,width=100,menubar=no,resizable=no,scrollbars=no,status=no,titlebar=no,top=0,location=no");
  if (!openWin) {
    alert("A popup blocker was detected. Please Remove popupblocker for this site");
	$("#pop_block").modal();
    } else {
    openWin.close();
		
   }
}
window.onload = checkPopup;
function ads_show(){
    console.log('working');
    $.ajax({
				type:'POST',
				url:"fetching-ads.php",
				data:{a:1},
				beforeSend: function(){
					$("#loader-ads-earn").css("display","block");
					},
				success: function(msg){
					$("#loader-ads-earn").css("display","none");
					$("#showing-ads").empty();
					$("#showing-ads").html(msg);
                                         var userid_ads=$("#userid").val();
		                         var count_ads=$("#count").val();
			                 var date_ads=$("#date").val();
                                          $.cookie("userid_ads",userid_ads,{path:"/"});
                                          $.cookie("count_ads",count_ads,{path:"/"});
                                          $.cookie("date_ads",date_ads,{path:"/"});
					console.log(msg);
				}
				});
}
$(document).ready(function(){
	$("#tut").modal();
	var userid_ads=$("#userid").val();
		                         var count_ads=$("#count").val();
			                 var date_ads=$("#date").val();
                                          $.cookie("userid_ads",userid_ads,{path:"/"});
                                          $.cookie("count_ads",count_ads,{path:"/"});
                                          $.cookie("date_ads",date_ads,{path:"/"});
    $('[data-toggle="tooltip"]').tooltip();
	$("#signin-form-show").click(function(){
		$(".singdiv").css("display","none");
		$(".tab-login-div").css("display","block");
		
	});
	
	 $.ajax({
		    type:'POST',
			url:"check_subscriber.php",
			data:{userid:userid},
			success: function(msg){
				    if(msg==100)
					   {
						   $("#subscribe").empty();
						   $("#subscribe").html('<img src="all_icons/subscribe-min.png" class="sub_style"><center><p style="font-family:playlist; font-size:16px; color:#000; margin-top:13%; " >SubscribeUs For More Latest Update In Our Website.</p><br /><div id="subscribe_btn1" class="sub_btn  ui-state-disabled">Subscribed</div></center>');
						   console.log(msg);
					   }
					  if(msg==000)
					    {
							$("#subscribe").empty();
							$("#subscribe").html('<img src="all_icons/subscribe-min.png" class="sub_style"><center><p style="font-family:playlist; font-size:16px; color:#000; margin-top:13%; " >SubscribeUs For More Latest Update In Our Website.</p><br /><input type="text" placeholder="Email" id="subscribe_email" class="form-control" style="width:60%; background:url(all_icons/email-min.png) no-repeat #FFF; padding-left:45px; padding-top:2px; line-height:34px;"/><div id="subscribe_btn" class="sub_btn">SubscribeUs</div></center>');
						}
				   
				}
			
		});
	
});
