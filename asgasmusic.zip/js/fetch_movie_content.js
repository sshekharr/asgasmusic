// JavaScript Document
$(document).ready(function(e) {
	if(moviename!=""&&id!=""&&$.trim(moviename).length!=0&&$.trim(id).length!=0)
	 {
    $.ajax({
		type:'POST',
		url:"music search.php",
		data:{moviename:moviename,id:id},
		success: function(msg){
			$("#contant_music").html(msg);
			
		}
	
		});
	 }
	if(songname&&moviename&&id) 
	   {
	   }
});