$(document).ready(function(e) {
	//notification fetching 
    $("#noti").click(function(e) {
        var val=1;
		$.ajax({
			    type:'POST',url:"notification.php",
				data:{val:val},
				success: function(msg){
					$("#notification_bar").modal({fadeDuration: 1000,
  fadeDelay: 1.75}).html(msg);
					}
						});
  }); 

$(".noti-pc").click(function(e) {
        var val=1;
		$.ajax({
			    type:'POST',url:"notification.php",
				data:{val:val},
				success: function(msg){
					$("#notification_bar").modal({fadeDuration: 1000,
  fadeDelay: 1.75}).html(msg);
					}
						});
  }); 

});
function close1(){
 var val1=10;
       //updating the fetching data.
		$.ajax({
			    type:'POST',url:"notification.php",
				data:{val1:val1},
				success: function(msg){
					console.log(msg);
					window.location.reload();
					}
						}); 
}