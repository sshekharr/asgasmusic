// JavaScript Document
$(document).ready(function(e) {
	$("#mob").click(function(){toastr.warning("Please Provide Us Correct Phone Number. It Will Help You During Redeeming The Amount");
	toastr.options={"positionClass": "toast-bottom-right"}});
    $("#fname").focusout(function(){fname();});
	$("#lname").focusout(function(){lname();});
	$("#email").focusout(function(){email();});
	$("#pass").focusout(function(){pass();});
	$("#repass").focusout(function(){repass();});
	$("#mob").focusout(function(){mob();});
	function fname()
	    {
			var fname=$("#fname").val();
			var fname_len=fname.length;
			if(fname_len<=2)
			   {
				   $("#input_singup_container_fn").removeClass("input_singup_container_fn");
				   $("#input_singup_container_fn").addClass("error_singup");
				    toastr.error("Please Enter The Valid First Name");
				   toastr.options={"positionClass": "toast-bottom-right"};
				   
			   }
			 else if(fname_len>2)
			   {
				   $("#input_singup_container_fn").removeClass("error_singup");
				   $("#input_singup_container_fn").addClass("input_singup_container_fn");
				   $.cookie("fname",fname,{path:"/"});
				    
				   
				   
			   }  
			
		}
	function lname(){
	      var lname=$("#lname").val();
		  var lname_len=lname.length;
		  if(lname_len<=2)
		     {
				   $("#input_singup_container_ln").removeClass("input_singup_container_ln");
				   $("#input_singup_container_ln").addClass("error_singup");
				   toastr.error("Please Enter The Valid Last Name");
				   toastr.options={"positionClass": "toast-bottom-right"};
			 }
		  else if(lname_len>2)
			   {
				   $("#input_singup_container_ln").removeClass("error_singup");
				   $("#input_singup_container_ln").addClass("input_singup_container_fn");
				   $.cookie("lname",lname,{path:"/"})
				   
			   }  	 
	}
	function email(){
	      var email=$("#email").val();
		  var email_len=email.length;
		  if(email_len<=5||$.trim(email).length==0)
		     {
				   $("#input_singup_container_em").removeClass("input_singup_container_em");
				   $("#input_singup_container_em").addClass("error_singup");
				   toastr.error("Please Enter The Valid Email Id");
				   toastr.options={"positionClass": "toast-bottom-right"};
				   $("#sibtn").css("display","none");
				   
			 }
		  else
		     {var email=$("#email").val();
				 $.ajax({
					 type:'POST',url:"email validation.php",data:{email:email},
					 success: function(msg){
						     if(msg==000)
							    {
									$("#input_singup_container_em").removeClass("error_singup");
									$("#input_singup_container_em").attr("class","correct");
				                    $.cookie("email",email,{path:"/"});
									$("#sibtn").css("display","block");
									console.log(msg);
									
									
								}
							 if(msg==111)
							    {
									$("#input_singup_container_em").removeClass("input_singup_container_em");
				                    $("#input_singup_container_em").addClass("error_singup");
									toastr.warning("Email is Linked With Other Account");
									toastr.options={"positionClass": "toast-bottom-right"};
									$("#sibtn").css("display","none");
									console.log(msg);

								}
							 if(msg==222)
							    {
									$("#input_singup_container_em").removeClass("input_singup_container_em");
				                    $("#input_singup_container_em").addClass("error_singup");
									toastr.error("Please Enter The Valid Email Id");
									toastr.options={"positionClass": "toast-bottom-right"};
									$("#sibtn").css("display","none");
									console.log(msg);
								}	
						 }
					 });
			 }
		  
	}
	function pass()
	       {
			   var pass=$("#pass").val();
			   var pass_len=pass.length;
			   if(pass_len<=6)
			      {
					$("#input_singup_container_pss").removeClass("input_singup_container_pss");
					$("#input_singup_container_pss").addClass("error_singup"); 
					toastr.error("PassWord Must Be Greater Than 6");
					toastr.options={"positionClass": "toast-bottom-right"};
					$("#sibtn").css("display","none");
				  }
				else
				  {
					  $("#input_singup_container_pss").removeClass("error_singup");
					$("#input_singup_container_pss").attr("class","correct");
					$.cookie("password",pass,{path:"/"});
					$("#sibtn").css("display","block");
					 
				  }
		   }
	function repass()
	       {
			   var repass=$("#repass").val();
			   var repass_len=repass.length;
			   var pass=$("#pass").val();
			   if(repass!==pass)
			      {
					$("#input_singup_container_repss").removeClass("input_singup_container_repss");
					$("#input_singup_container_repss").addClass("error_singup");
					toastr.error("Please Type The Valid PassWord");
					toastr.options={"positionClass": "toast-bottom-right"};
					$("#sibtn").css("display","none");
					
				  }
				else
				  {
					$("#input_singup_container_repss").removeClass("error_singup");
					$("#input_singup_container_repss").addClass("input_singup_container_fn");
					$.cookie("repassword",repass,{path:"/"});
					$("#sibtn").css("display","block");
					  
				  }
		   }
	function mob()
	       {
			    var mob=$("#mob").val();
				var mob_len=$("#mob").val().length;
			 if(mob_len<=9)
			     {
					 toastr.warning("Please Enter The Correct Number");
					toastr.options={"positionClass": "toast-top-right"};
					 $("#input_singup_container_mob").removeClass("input_singup_container_mob");
					 $("#input_singup_container_mob").addClass("error_singup");
					 $("#sibtn").css("display","none");
				 }
			else if(mob_len>10)
			     {
					 toastr.warning("Please Enter The Correct Number");
					toastr.options={"positionClass": "toast-top-right"};
					 $("#input_singup_container_mob").removeClass("input_singup_container_mob");
					 $("#input_singup_container_mob").addClass("error_singup");
					 $("#sibtn").css("display","none");
				 }	 
			else
			    {
					$.ajax({
						type:'POST',url:"phoneNo Verification.php",data:{mob:mob},
						success: function(msg){
							  if(msg==111)
							      {
									  toastr.warning("Mobile Number Is Already Linked With Another Account");
					                  toastr.options={"positionClass": "toast-bottom-right"};
					                   $("#input_singup_container_mob").removeClass("input_singup_container_mob");
					                   $("#input_singup_container_mob").addClass("error_singup");
									   $("#sibtn").css("display","none");
									  
								  }
								if(msg==000)
								    {
										$("#input_singup_container_mob").removeClass("error_singup");
					                   $("#input_singup_container_mob").addClass("correct");
									   $.cookie("mob",mob,{path:"/"});
									   $("#sibtn").css("display","block");
									   
									}
							}
						});
				}
				
				 
		   }
		
		$("#singup").click(function(e) {
			
            var fname=$.cookie("fname");
			var lname=$.cookie("lname");
			var email=$.cookie("email");
			var pass=$.cookie("password");
			var repass=$.cookie("repassword");
			var mob =$.cookie("mob");
			        if(fname&&lname&&email&&pass&&repass&&mob)
					     {
							 var frname =$("#fname").val();
							 var laname=$("#lname").val();
							 var Email=$("#email").val();
							 var Pass=$("#pass").val();
							 var Mob=$("#mob").val();
							 $("#sibtn").empty();
							  $("#sibtn").html('<img src="all_icons/loading.gif" width="90" height="90">');
							 $.ajax({
								      type:'POST',
									  url:"signingup.php",
									  data:{'frname':frname,'laname':laname,'Email':Email,'Pass':Pass,'Mob':Mob},
									  success: function(update_msg){
										       
											         alert(update_msg);
                                                                                                 console.log(update_msg);
													 $.removeCookie("fname", {path:'/'});
													 $.removeCookie("lname", {path:'/'});
													 $.removeCookie("email", {path:'/'});
													 $.removeCookie("password", {path:'/'});
													 $.removeCookie("repassword", {path:'/'});
													 $.removeCookie("mob", {path:'/'});
													 $("#sigup_form").empty();
													 $("#sigup_form").css("background","white");
													 $("#sigup_form").html('<img src="all_icons/mail-smiley.png" style="width:80%; height:80%;">');
													   
													   
													 
										  
										  }
									  
								 });
						 }
			        });
});