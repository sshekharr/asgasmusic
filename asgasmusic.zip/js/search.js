// JavaScript Document
$(document).ready(function(e) {
    $("#serch_btn").click(function(e) {
        var serch=$("#search").val();
		if($.trim(serch).length==0)
		toastr.error("Please Enter Some Text To Search.");
		
		else
		   {
		$.ajax({
			  type:'POST',
			  url:"search.php",
			  data:{val:serch},
			  success: function(msg){
				  $("#search_show").modal({fadeDuration: 1000,
  fadeDelay: 1.75}).html(msg);
				  }
			});}
		
		
    });
	
	$("#serch_btn_pc").click(function(e) {
        var serch=$("#search-pc").val();
		if($.trim(serch).length==0)
		toastr.error("Please Enter Some Text To Search.");
		
		else
		   {
		$.ajax({
			  type:'POST',
			  url:"search.php",
			  data:{val:serch},
			  success: function(msg){
				  $("#search_show").modal({fadeDuration: 1000,
  fadeDelay: 1.75}).html(msg);
                 $("#search_show").css("display","inline-block");
				  }
			});}
		
		
    });
});