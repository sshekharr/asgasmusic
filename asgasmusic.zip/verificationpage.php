<?php
if(isset($_GET['username'])&&isset($_GET['email'])&&isset($_GET['mobileNo'])&&isset($_GET['id']))
   {
	   include "db.php";
$name=explode(".",$_GET['username']);
$email=$_GET['email'];
$mob_no= $_GET['mobileNo'];
$random_id= explode('.',$_GET['id']);
$id=$random_id[0];
$uniId=$random_id[1];
$newuniId=uniqid();
$active=1;
$sql="SELECT * FROM `login-&-signup-data`WHERE `FirstName`='$name[0]' AND `LastName`='$name[1]' AND `Email`='$email' AND `mobileNo`='$mob_no' AND `randomId`='$id' AND `uniId`='$uniId'";
if($result=mysqli_query($conn,$sql))
     {
		 if(mysqli_num_rows($result)===1)
		     {
				 echo"EMAIL ID VERIFIED. PLEASE REFRESH THE PAGE";
				$sql_1="UPDATE `login-&-signup-data` SET `EmailActivation`='$active',`uniId`='$newuniId' WHERE`randomId`='$id' AND `Email`='$email' AND `mobileNo`='$mob_no'";
				$query=mysqli_query($conn,$sql_1);
				
			 }
		else
     {
		 header('location:index.php');
	 }	 
		     
	 }
else
     {
		 header('location:index.php');
	 }
	 
   }
 else
    {
		echo"please verify with correct information.";
		
		
	}
?>