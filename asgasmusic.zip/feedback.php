<?php
if(isset($_POST['opt'])&&isset($_POST['msg'])&&isset($_POST['userid']))
{
	 include"db.php";
     $opt=mysqli_escape_string($conn_feedback,$_POST['opt']);
	 $msg=mysqli_escape_string($conn_feedback,$_POST['msg']);
	 $userid=mysqli_escape_string($conn_feedback,$_POST['userid']);
	 $id=uniqid();
	 date_default_timezone_set("Asia/kolkata");
	   $timezone=date_default_timezone_get();
	 $date=date('d-m-y');
	 $sql="INSERT INTO `feedback-data`(`Randomid`, `userid`, `opt`, `msg`,`date`,`status`) VALUES ('$id','$userid','$opt','$msg','$date','pending')";
	 $query=mysqli_query($conn,$sql);
	 	
}
?>