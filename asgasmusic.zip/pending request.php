<?php
include "db.php";
sleep(3.5);
$status='pending';
$sql="SELECT * FROM `money-request` WHERE `status`='$status'";
$query=mysqli_query($conn,$sql);
$count=mysqli_num_rows($query);
if($count>0)
    {
		while($fetch=mysqli_fetch_assoc($query))
		{	
		if($fetch['recharge_opt']==='Paytm')
		   {
			   echo '<div id="" style="width:100%; height:100px; background: center url(all_icons/paytm_icon2-min.png) no-repeat; border:1px solid #000; border-radius:8px; margin-bottom:15px;"><div id="" style="font-family:playlist; width:90px; height:50px; float:left; font-size:35px; margin-top:25px; padding-left:8px;">Rs:-'.$fetch['amount'].'</div><div id="status" style="float:right; font-family:playlist; font-size:18px; margin-top:65px; padding-right:8px;">'.$fetch['status'].'</div><div id="txnId" style="font-family:playlist; width:100%; height:35px; font-size:14px; float:left; margin-top:-4px; margin-left:-60px;">txn Id:-'.$fetch['txt_id'].'</div></div>';
			   
		   }
		if($fetch['recharge_opt']==='Recharge')
		   {
			   echo '<div id="" style="width:100%; height:100px; background: center url(all_icons/recharde_icon2-min.png) no-repeat; border:1px solid #000; border-radius:8px; margin-bottom:15px;"><div id="" style="font-family:playlist; width:90px; height:50px; float:left; font-size:35px; margin-top:25px; padding-left:8px;">Rs:-'.$fetch['amount'].'</div><div id="status" style="float:right; font-family:playlist; font-size:18px; margin-top:65px; padding-right:8px;">'.$fetch['status'].'</div><div id="txnId" style="font-family:playlist; width:100%; height:35px; font-size:14px; float:left; margin-top:-4px; margin-left:-60px;">txn Id:-'.$fetch['txt_id'].'</div></div>';
		   }
		}
		   
	}
else
   {
	 echo' <div id="" style="width:100%; height:100px; border:1px solid #000; border-radius:8px; margin-bottom:15px;"><div id="" style="font-family:playlist; width:90px; height:50px; font-size:35px; margin-top:25px; padding-left:8px;"><h4><center>No Pending Request.</center></h4></div> ';
   }
	
?>
