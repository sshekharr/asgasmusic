<?php
    $headers="noreply@asgasmusic.com";
require("class.phpmailer.php");

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "bh-ht-3.webhostbox.net";

$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Port = 465;
$mail->Username = "noreply@asgasmusic.com";
$mail->Password = "asgasmusic@2016";

$mail->From = $headers;
$mail->FromName = "Test User";
$mail->AddAddress("shekhar.kahar10@gmail.com");
//$mail->AddReplyTo("mail@mail.com");

$mail->IsHTML(true);

$mail->Subject = "AsgasMusic email confirmation";
$mail->Body = "<h1>Please Complete Yourm Verification By Clicking In Given Link.</h1><br>http://www.asgasmusic.com/verificationpage.php?username='.$fname.'.'.$lname.'&email='.$email.'&mobileNo='.$mob.'&id='.$id1";




if(!$mail->Send())
{
echo "SignUp Failed Please Refresh The Page And Try Again.";
	$sql_delet="DELETE FROM `login-&-signup-data` WHERE `randomId`='$id'";
	mysqli_query($conn_login_user,$sql_delet);
exit;
}

echo "SignUp Complete!!.Please Complete The SignUp procedure By clicking The link Which We send In Your Given Mail Address. ";

?>