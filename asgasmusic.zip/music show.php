﻿<?php ini_set('display_errors', 'On');
error_reporting(E_ALL); 
session_start();
session_regenerate_id();
include "db.php";
if(isset($_GET['id'])&&isset($_GET['Moviename'])&&isset($_GET['type']))
  {
	  $moviename_play=$_GET['Moviename'];
	  $id_play=$_GET['id'];
	  $type=$_GET['type'];
		$sql_show_content="SELECT * FROM `music_name_&_details` WHERE`MovieName`='$moviename_play' AND `RandomId`='$id_play' AND `type`='$type'";
		$query_show_content=mysqli_query($conn,$sql_show_content);
		$count_show_content=mysqli_num_rows($query_show_content);
  }
  if(isset($_GET['Id'])&&isset($_GET['movieName'])&&isset($_GET['SongName'])&&isset($_GET['type']))
    {
		$moviename_play=$_GET['movieName'];
	  $id_play=$_GET['Id'];
	  $song_play=$_GET['SongName'];
	  $type=$_GET['type'];
		$sql_show_content="SELECT * FROM `music_name_&_details` WHERE`MovieName`='$moviename_play' AND `RandomId`='$id_play' AND `SongName`='$song_play' AND `type`='$type'";
		$query_show_content=mysqli_query($conn,$sql_show_content);
		$count_show_content=mysqli_num_rows($query_show_content);
	}
if(isset($_GET['moviename'])&&isset($_GET['type']))	
   {
	   $moviename_play=$_GET['moviename'];
	   $type=$_GET['type'];
		$sql_show_content="SELECT * FROM `music_name_&_details` WHERE`MovieName`='$moviename_play' AND `type`='$type'";
		$query_show_content=mysqli_query($conn,$sql_show_content);
		$count_show_content=mysqli_num_rows($query_show_content);
   }
?>
<!DOCTYPE html>
<html>
<head>
<title>Asgas Music - Download Song & Earn Money</title>
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/stylesheet.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="all_icons/asgasmusic logo.png" type="png/icon">
<link href="css/reste_css.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link href="css/jquery.modal.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/toastr.css" type="text/css">
<link rel="stylesheet" type="text/css" href="audioplayerengine/initaudioplayer-1.css">
<script src="js/jquery-3.0.0.min.js"></script><script type="text/javascript">
var infolinks_pid = 2923300;
var infolinks_wsid = 0;
</script>
<script type="text/javascript" src="//resources.infolinks.com/js/infolinks_main.js"></script>
<script language="javascript" src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
<meta name="theme-color" content="#f6d60d">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="charset" content="ISO-8859-1">
<meta name="description" content="As the name suggests Asgasmusic is a music site but not as the other available sites on Internet! Here we provide you the opportunity of earning! Yes, earning by downloading!">
<meta name="keywords" content="music, mp3, song download, earn money, paytm money, hindi song, english song, hindi songs,english songs, album, new movie song, audio, songs collection, new songs, bollywood songs, english artist songs, latest songs">

</head>
<body><!--Start of the Body-->
<header class="header-mob"><!--Start of the header for mobile-->
	<center>
		<a href="index.php"><img src="all_icons/asgasmusic logo with site name.png" class="mob-logo"></a>
		   
	</center>
</header><!--End of the header for mobile-->
<header id="header" class="header"><!--Start of the header-->
<div id="social" class="social container"><!--Start of the social-->
<a href="#" ><i id="" data-toggle="tooltip" data-placement="bottom" title="Whatsapp Us" class="social_icon fa fa-whatsapp" aria-hidden="true" style="font-size:50px;"></i></a><!--End of the Whatsapp-->
<a href="https://www.facebook.com/Asgasmusic-1253884004688389/" ><i id="" data-toggle="tooltip" data-placement="bottom" title="LikeUs On Facebook" class="social_icon fa fa-facebook-square" aria-hidden="true" style="font-size:50px;"></i></a><!--End of the fb-->
<a href="#" ><i id="" data-toggle="tooltip" data-placement="bottom" title="FollowUs On Googleplus" class="social_icon fa fa-google-plus-square" aria-hidden="true" style="font-size:50px;"></i></a><!--End of the googleplus-->
<a href="https://twitter.com/musicasgas" ><i id="" data-toggle="tooltip" data-placement="bottom" title="FollowUs On Twitter" class="social_icon fa fa-twitter-square" aria-hidden="true" style="font-size:50px;"></i></a><!--End of the twitter-->
<a href="#" ><i id="" data-toggle="tooltip" data-placement="bottom" title="FollowUs On Linkedin" class="social_icon fa fa-linkedin-square" aria-hidden="true" style="font-size:50px;"></i></a><!--End of the linkedin-->
</div><!--End of the social-->
<div class="container logo"><!--start of the header logo container-->
<a href="index.php"><img src="all_icons/asgasmusic logo with site name.png" width="200" height="200" class="header_logo" /></a>
<div id="#" class="menu"><!--Start of the header menu container-->
    
	<a href="index.php" class="noline" style="text-decoration: none;"><div id="" class="menu_inside  ">HOME</div></a>
    <a href="music.php" class="noline" style="text-decoration: none;"><div id="" class="menu_inside">Hindi</div></a>
    <a href="music Hollywood.php"#"" class="noline" style="text-decoration: none;"><div id="" class="menu_inside ">English</div></a>
    <a href="Classical-best of me song list.php" class="noline" style="text-decoration: none;"><div id="" class="menu_inside ">Best Of Me</div></a>
    <a href="#aboutus_modal" class="noline" style="text-decoration: none;" rel="modal:open"><div id="" class="menu_inside ">AboutUs</div></a>
</div><!--End of the header menu container-->
<br><br><br><br>
<div class="mobi-search"><!--Start of the tab search-->
	<div id="" class="mobi-box_searchcontainer"><!--Start of the search-->
		<center>
			<div class="mobi-searchatcenter"><div id="serch" class="serch">
			<input type="text" class="mobi-serch_data" id="search" placeholder="search"/>
			<i class="fa fa-search mobi-serch_icon" aria-hidden="true" id="serch_btn" style="font-size: 35px; color: #000;"></i>		
			</div>
			</div>
		</center>
	</div><!--End of the search-->
</div><!--Start of the tab search-->
</div><!--End of the header logo container-->
</header><!--End of the header-->
<div class="container-fluid"><!--Start of the main contain-->
   
    <center>
    <div style="" class="singdiv signdiv-style">
   	<center>
    	<button id="signin-form-show" style="" class="sub_btn signin-form-show">
    		Click Here For Signin/Signup
    	</button>
    	</center>
    </div>
    	<div class="tab-login-div" style="display: none;"><!--Start of the tab login/user cointainer-->
    		<?php if(!isset($_SESSION['userid'])){ echo'<center><strong class="tab-font">Login/Signup</strong></center>
    		<div>
    			<center>
    				<img src="all_icons/icons-about-user-min.png" width="100" height="100">
    			</center>
    		</div>
		<div class="tab-user_name_logo"></div>
		<div class="tab-input">
			<input type="text" placeholder="EMAIL" id="signin_email" class="tab-normal" name="signin_email" value=""/>
			</div><br><br><br><br>
		<div class="tab-user_pass_logo"></div>
		<div class="tab-input-pass">
			<input type="password" placeholder="PASSWORD" id="signin_pass" class="tab-normal" name="signin_pass">
			</div>
			<div id="Forgottenaccountpass" style="float:right; color:#000; font-family:playlist; padding-right:15px; cursor:pointer; width:100%; margin-right:-20%;">Reset Acc Pass?</div>
                <center><div class="tab-signin-signup"><!--Start of signin-signup Button-->
                	<div class="tab-supbutt" id="signin_1"><center>SignIn</center></div>
                	<a href="#sigup_form" rel="modal:open"><div class="tab-signupbutt" id="signupbtn"><center>SignUp</center></div></a>
                </div></center><!--End of signin-signup Button-->';}?>
			
			<?php if(isset($_SESSION['userid'])){
echo '
<div id="user" class="duration animated bounceInRight">
<center><img src="all_icons/reggae-clipart-cbf299e8fb9244926994ad7db1ecee5bb_p_400-min.png" id="user_icon"></center>
<div id="user_content">
<div id="user_name">';}?><?php if(isset($_SESSION['userid'])){ $userid=$_SESSION['userid']; $sql="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'"; $query=mysqli_query($conn,$sql); $fetch=mysqli_fetch_array($query); $coun=mysqli_num_rows($query);
	$name=strtoupper($fetch['FirstName']." ".$fetch['LastName']); echo "<b>".$name."</b></div>"; }?>
<?php if(isset($_SESSION['userid'])){
	$user=$_SESSION['userid'];
	$sql1="SELECT * FROM `notification-user` WHERE `user_id`='$user' AND `status`='unread'";
	$qury=mysqli_query($conn,$sql1);
	$count=mysqli_num_rows($qury);
   if($count<=0)
      {
		  echo'</div>
<div id="user_noti_setting">
<table id="user_noti_sett">
<tbody>
<tr>
<th><div id="noti_num" class=""><center></center></div><div id="noti" title="Notification"></div></th>
<th><div id="redeem" title="Redeem"></div></th>
<th><div id="setting" title="Setting"></div></th>
<th><a href="logout.php"><div id="logout" title="Logout"></div></a></th>
</tr>
</tbody>
 </table>
</div>';
	  }
  else
     {
		echo'</div>
<div id="user_noti_setting">
<table id="user_noti_sett">
<tbody>
<tr>
<th><div id="noti_num" class=""><center>'.$count.'</center></div><div id="noti" title="Notification"></div></th>
<th><div id="redeem" title="Redeem"></div></th>
<th><div id="setting" title="Setting"></div></th>
<th><a href="logout.php"><div id="logout" title="Logout"></div></a></th>
</tr>
</tbody>
 </table>
</div>'; 
	 }
}?>

    	</div><!--End of the tab login/user cointainer-->
    </center>
    
	<div id="" class="box_searchcontainer"><!--Start of the search-->
		<center>
			<div class="searchatcenter"><div id="serch" class="serch">
			<input type="text" class="serch_data" id="search-pc" placeholder="search"/>
			<i class="fa fa-search serch_icon" aria-hidden="true" id="serch_btn_pc" style="font-size: 35px; color: #000;"></i>		
			</div>
			</div>
		</center>
	</div><!--End of the search-->
	<center>
      <div		
	</center>
	<div id="logindiv" class="logindiv"><!--Start of the login container-->
		
		<?php if(!isset($_SESSION['userid'])){ echo'<center><strong class="font">Login/Signup</strong></center>
		<div class="user_name_logo"></div>
		<div class="input">
			<input type="text" placeholder="EMAIL" id="signin_emailpc" class="normal" name="signin_email" value=""/>
			</div>
		<div class="user_pass_logo"></div>
		<div class="input">
			<input type="password" placeholder="PASSWORD" id="signin_passpc" class="normal" name="signin_pass">
			</div>
			<a href="#passreset_request" rel="modal:open"><div id="Forgottenaccountpass" style="float:right; color:#000; font-family:playlist; padding-right:15px; cursor:pointer">Reset Acc Pass?</div></a>
                <center><div class="signin-signup"><!--Start of signin-signup Button-->
                	<div class="supbutt" id="signin_pc"><center>SignIn</center></div>
                	<a href="#sigup_form" rel="modal:open"><div class="signupbutt" id="signupbtn"><center>SignUp</center></div></a>
                </div></center><!--End of signin-signup Button-->';}?>
                
                
<?php if(isset($_SESSION['userid'])){
echo '
<div id="user" class="duration animated bounceInRight">
<center><img src="all_icons/reggae-clipart-cbf299e8fb9244926994ad7db1ecee5bb_p_400-min.png" id="user_icon"></center>
<div id="user_content">
<div id="user_name">';}?><?php if(isset($_SESSION['userid'])){ $userid=$_SESSION['userid']; $sql="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'"; $query=mysqli_query($conn,$sql); $fetch=mysqli_fetch_array($query); $coun=mysqli_num_rows($query);
	$name=strtoupper($fetch['FirstName']." ".$fetch['LastName']); echo "<b>".$name."</b></div>"; }?>
<?php if(isset($_SESSION['userid'])){
	$user=$_SESSION['userid'];
	$sql1="SELECT * FROM `notification-user` WHERE `user_id`='$user' AND `status`='unread'";
	$qury=mysqli_query($conn,$sql1);
	$count=mysqli_num_rows($qury);
   if($count<=0)
      {
		  echo'</div>
<div id="user_noti_setting">
<table id="user_noti_sett">
<tbody>
<tr>
<th><div id="noti_num" class=""><center></center></div><div id="noti" title="Notification" class="noti-pc"></div></th>
<th><div id="redeem" title="Redeem" class="redeem-pc"></div></th>
<th><a href="#setting_menu" rel="modal:open"><div id="setting" title="Setting"></div></a></th>
<th><a href="logout.php"><div id="logout" title="Logout"></div></a></th>
</tr>
</tbody>
 </table>
</div>';
	  }
  else
     {
		echo'</div>
<div id="user_noti_setting">
<table id="user_noti_sett">
<tbody>
<tr>
<th><div id="noti_num" class="noti_num"><center>'.$count.'</center></div><div id="noti" title="Notification" class="noti-pc"></div></th>
<th><div id="redeem" title="Redeem" class="redeem-pc"></div></th>
<th><div id="setting" title="Setting"></div></th>
<th><a href="logout.php"><div id="logout" title="Logout"></div></a></th>
</tr>
</tbody>
 </table>
</div>'; 
	 }
}?>

</div>

               
	</div><!--End of the login container-->
	<div class="ads160"><!--Start of ads160 div-->
		<?php 
		      include("db.php");
		       $__adsid__=rand(1,16);
		       $_sql_="SELECT * FROM `160x600` WHERE `id`='$__adsid__'";
		       $_query=mysqli_query($conn,$_sql_);
		       $_fetch=mysqli_fetch_assoc($_query);
		       echo($_fetch['code']);
		?>
	</div><!--End of ads160 div-->
	<center>
	<div class="bollywood_latest_song"><!--Start of the Bollywood latest song-->
	<div class="song-content-header"><center><!--Start of the Earning rate showing-->
	TODAY EARNING RATE ='<?php $sql_get_amount="SELECT * FROM `music_name_&_details`";
 $query_get_amount=mysqli_query($conn,$sql_get_amount);
 $fetch_get_amount=mysqli_fetch_assoc($query_get_amount);
  echo $fetch_get_amount['Amount']; ?> 'PER SONG.</center></div><!--End of the Earning rate showing-->
  <?php $show =explode(1,include"movie detail in download page.php");
         echo $show[0];
        ?>
 <div id="ads300x250" style=""><!--Start of the 1300X250 ads-->
 	<script>var adParams = {s: 1000222692, w: 300, h: 250, c: 4, type: 6, devices: 'all', blank: true};</script><script src="//js.srcsmrtgs.com/js/ad.js"></script>
				    			    
</div><!--End of the 1300X250 ads-->
		<div style="" id="media_player" class="dur"><!--Start of the media player-->
    
    <!-- Insert to your webpage where you want to display the audio player -->
    <div id="amazingaudioplayer-1" style="" class="player">
        <ul class="amazingaudioplayer-audios" style="display:none;" id="media_player_list_play">
           <?php
		   while($fetch_show_content=mysqli_fetch_assoc($query_show_content))
		  {
			  echo '<li data-artist="'.$fetch_show_content['Singer-s'].'" data-title="'.$fetch_show_content['SongName'].'" data-album="('.$fetch_show_content['Movie/Album'].')" data-info="" data-image="all_icons/asgasmusic logo with site name2-min.png" data-duration="'.$fetch_show_content['Duration'].'">
                <div class="amazingaudioplayer-source " data-src="'.$fetch_show_content['address'].'" data-type="audio/mpeg" />
            </li>';
		  }
		   ?>
        </ul>
      
    </div></div><!--End of the media player-->
    <div style="float: left; width: 100%;">
   <?php
if(isset($_GET['id'])&&isset($_GET['Moviename'])&&isset($_GET['type']))
  {
	 $moviename=$_GET['Moviename'];
	 $id=$_GET['id'];
	 $type=$_GET['type'];
	 echo '<div ><center><h1 id="h1">'.$moviename.'</h1></center></div>';
	$sql_album="SELECT * FROM `albumart_&_details` WHERE `moviename`='$moviename' AND `type`='$type'";
	 $query_album=mysqli_query($conn,$sql_album);
	 $count_album=mysqli_num_rows($query_album);
	 $fetch_album=mysqli_fetch_assoc($query_album);
	 $sql_fetch_data="SELECT * FROM `music_name_&_details` WHERE `MovieName`='$moviename' AND `RandomId`='$id' AND `type`='$type'";
	 $query_fetch_data=mysqli_query($conn,$sql_fetch_data);
	 if($count_album==1)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
				    echo '<div class="song shadow00" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}
	 if($count_album>1)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
					echo '<div class="song shadow00" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}
	 if($count_album==0)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
					echo '<div class="song shadow00" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}		
  }
  if(isset($_GET['Id'])&&isset($_GET['movieName'])&&isset($_GET['SongName'])&&isset($_GET['type']))
       {
	 $moviename=$_GET['movieName'];
	 $id=$_GET['Id'];
	 $songname=$_GET['SongName'];
	 $type=$_GET['type'];
	 echo '<div ><center><h1 id="h1">'.$moviename.'</h1></center></div>';
	 $sql_album="SELECT * FROM `albumart_&_details` WHERE `moviename`='$moviename' AND `type`='$type'";
	 $query_album=mysqli_query($conn,$sql_album);
	 $count_album=mysqli_num_rows($query_album);
	 $fetch_album=mysqli_fetch_assoc($query_album);
	 $sql_fetch_data="SELECT * FROM `music_name_&_details` WHERE `MovieName`='$moviename' AND `RandomId`='$id' AND `SongName`='$songname' AND `type`='$type'";
	 $query_fetch_data=mysqli_query($conn,$sql_fetch_data);
	 if($count_album==1)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
				    echo '<div class="song shadow00" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}
	 if($count_album>1)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
					echo '<div class="song shadow00" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}
	 if($count_album==0)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
					echo '<div class="song shadow00" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}		
		   
	   }
	 if(isset($_GET['moviename'])&&isset($_GET['type']))
       {
	 $moviename=$_GET['moviename'];
	 $type=$_GET['type'];
	 echo '<div ><center><h1 id="h1">'.$moviename.'</h1></center></div>';
	 $sql_album="SELECT * FROM `albumart_&_details` WHERE `moviename`='$moviename' AND `type`='$type'";
	 $query_album=mysqli_query($conn,$sql_album);
	 $count_album=mysqli_num_rows($query_album);
	 $fetch_album=mysqli_fetch_assoc($query_album);
	 $sql_fetch_data="SELECT * FROM `music_name_&_details` WHERE `MovieName`='$moviename' AND `type`='$type'";
	 $query_fetch_data=mysqli_query($conn,$sql_fetch_data);
	 if($count_album==1)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
				    echo '<div class="song shadow00" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}
	 if($count_album>1)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
					echo '<div class="song" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}
	 if($count_album==0)
	    {
			while($fetch_fetch_data=mysqli_fetch_assoc($query_fetch_data))
			    {
					echo '<div class="song" "downloadsongname="'.$fetch_fetch_data['SongName'].'" downloadsongid="'.$fetch_fetch_data['RandomId'].'"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_album['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_fetch_data['SongName'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="350">'.$fetch_fetch_data['SongName'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_fetch_data['Movie/Album'].'</div>
	</div><!--End of the song ditails div-->
	</div><!--End of the song list div-->';	
				}
		}		
		   
	   } 
?></div>
	<div class="more-song-btn">
		<center>
			
		</center>
	</div>
	</div><!--End of the Bollywood latest song-->
	</center>
	
</div></div><!--End of the main contain-->
<div class="mob-menu">
<center>
	<a href="#" class="noline" style="text-decoration: none;" ><div class="home "><i class="fa fa-home icon " aria-hidden="true"></i>Home</div></a><!--Start of the Home-->
	<div class="music atthatplace" id="music" ><i class="fa fa-music icon atthatplaceicon" aria-hidden="true"></i>Music<i class="fa fa-chevron-circle-down icon-right " aria-hidden="true" style="color: #fff;"></i></div></a><!--Start of the Music-->
	<div class="music-content" show="none" id="music-content">
		<a href="music.php" class="noline" style="text-decoration: none;" ><div class="music "><i class="fa fa-music icon" aria-hidden="true"></i>Hindi</div></a>
		<a href="music Hollywood.php" class="noline" style="text-decoration: none;" ><div class="music"><i class="fa fa-music icon" aria-hidden="true"></i>English</div></a>
		<a href="Classical-best of me song list.php" class="noline" style="text-decoration: none;" ><div class="music"><i class="fa fa-music icon" aria-hidden="true"></i>Best Of Me</div></a>
	</div>
	<a href="#aboutus_modal" class="noline" style="text-decoration: none;" rel="modal:open"><div class="about-us"><i class="fa fa-info-circle icon" aria-hidden="true"></i>About Us</div></a><!--Start of the about us-->
	<div class="social-mob"><!--Start of the social-->
	<a href="#" ><i id="" data-toggle="tooltip" data-placement="bottom" title="Whatsapp Us" class="social_icon mobi-icon fa fa-whatsapp" aria-hidden="true" style=""></i></a><!--End of the Whatsapp-->
	<a href="https://www.facebook.com/Asgasmusic-1253884004688389/" ><i id="" data-toggle="tooltip" data-placement="bottom" title="LikeUs On Facebook" class="social_icon mobi-icon fa fa-facebook-square" aria-hidden="true"></i></a><!--End of the fb-->
<a href="#" ><i id="" data-toggle="tooltip" data-placement="bottom" title="FollowUs On Googleplus" class="social_icon mobi-icon fa fa-google-plus-square" aria-hidden="true" ></i></a><!--End of the googleplus-->
<a href="https://twitter.com/musicasgas" ><i id="" data-toggle="tooltip" data-placement="bottom" title="FollowUs On Twitter" class="social_icon mobi-icon fa fa-twitter-square" aria-hidden="true" ></i></a><!--End of the twitter-->
<a href="#" ><i id="" data-toggle="tooltip" data-placement="bottom" title="FollowUs On Linkedin" class="social_icon mobi-icon fa fa-linkedin-square" aria-hidden="true"></i></a><!--End of the linkedin-->
</div>
	</center>
</div>
<input type="hidden" name="IL_IN_TAG" value="2"/>
<div id="footer" class="footer inner_shadow"><!--Start of the footer pc-->
<div  id="subscribe" style="" class="inner_shadow subscribe">
<img src="all_icons/subscribe-min.png"style="" class="sub_style">
<center><p style="font-family:playlist; font-size:16px; color:#000; margin-top:13%; " >
SubscribeUs For More Latest Update In Our Website.
</p></center><br />
<center>
<input type="text" placeholder="Email" id="subscribe_email" class="form-control" style="width:60%; background:url(all_icons/email-min.png) no-repeat #FFF; padding-left:45px; padding-top:2px; line-height:34px; box-shadow: 0px 0px 15px #000;"/>
<div id="subscribe_btn" class="sub_btn">SubscribeUs</div>
</center>
</div>
<div  id="feedback_footer" style="" class="inner_shadow feedback_footer">
<center><p style="font-family:playlist; font-size:16px; color:#000; margin-top:5%;" >
If You Are Facing Any Problem. Give Us Feedback We Will Solve It Within 48 hr.
</p><br />
<center><a href="#feedback_admin" rel="modal:open" style="text-decoration:none margin-top:9%; text-decoration: none;"><div id="feedback_btn" class="sub_btn">Feedback</div></a></center><br>
<p style="font-family:playlist; font-size:16px; color:#000; margin-top:1%;" >
or Mail Us in (facingproblem@asgasmusic.com) With Your Registered EmailId.
</p></center>
</div>
<div  id="Contact_Us" style="" class="inner_shadow Contact_Us">
<center><p style="font-family:playlist; font-size:16px; color:#000; margin-top:10%;" >
Stay In Touch WithUs And SupportUs.
</p>
	<div style="float: left;">
<div style="margin-left:30px; width:80%; margin-top:15px; margin-bottom:5px; font-family:playlist; font-size:16px; color:#000; float:left; line-height:30px; padding-left:20px; padding-right:20px;" id="wa_small"><i id=""  class=" fa fa-whatsapp" aria-hidden="true" style="font-size:30px; color: #000; float: left; margin: 1px;"></i><div style=" float:left;margin-left: 3px;">+91 9593600154</div></div><br>
<div style="margin-left:30px; width:80%; margin-bottom:5px; font-family:playlist; font-size:16px; color:#000; float:left; line-height:30px; padding-left:20px; padding-right:20px;" id="fb_small"><a href="https://www.facebook.com/Asgasmusic-1253884004688389/" style="text-decoration: none; color: #000;"><div style=" float:left; margin-left: 3px; min-width: 185px;"><i id="" class=" fa fa-facebook-square" aria-hidden="true" style="font-size:30px; float: left; color: #000; margin-left: -2px; margin-right: 2px"></i>www.facebook.com</div></a></div><br>
<div style="margin-left:30px; width:80%; font-family:playlist; font-size:16px; color:#000; float:left; line-height:30px; padding-left:20px; padding-right:20px;" id="tw_small"><a href="https://twitter.com/musicasgas" style="text-decoration: none; color: #000;"><i id="" class=" fa fa-twitter-square" aria-hidden="true" style="font-size:30px; float: left; margin: 1px;"></i><div style=" float:left; margin-left: 3px;">www.twitter.com</div></a></div></div><br><br><br><br><br>
<center><a href="#contactus" rel="modal:open" style="text-decoration:none;"><div id="contact" class="sub_btn_con" style="">ContactUs</div></a></center>
</div></center>
<div id="copyright" style="" class=" inner_shadow copyright">
<center>
<div class="copyright-txt">Copyrights © 2016 - <?php echo date('Y');?> Asgasmusic.Com, All Right Reserved.</div>
</center>
</div>
</div><!--End of the footer pc-->

<div id="feedback_admin" style="background: url(all_icons/yellow-vector-background-min-min.png); display:none; min-width: 500px;"><!--feedback system pc-->
<div id="islogin" status="<?php echo $_SESSION['userid'] ?>" style="display:none;" hidden="hidden"></div>
<h1 style="font-family:playlist; font-size:18px; text-align:center; color:#000;">FEEDBACK</h1>
<center><img src="all_icons/icons-about-user-min.png" width="100" height="100" style="margin:10px;"></center>
<div id="line" style="margin-left:-1px;"></div><br>
<center>
<select id="feedback_data"  class="selectpicker" onChange="opt()">
<optgroup label="Error happening">
<option value="null" selected>Select the error</option>
<option value="unable to send reset password email.">unable to send reset password email</option>
<option value="error occuring during account activation.">error occuring during account activation</option>
<option value="unable to redeem the amount.">unable to redeem the amount</option>
<option value="Wallet Balance is not showing.">Wallet Balance is not showing</option>
<option value="unable to login in account.">unable to login in account</option>
<option value="Amount Not credited in your Paytm account.">Amount Not credited in your Paytm account</option>
</optgroup>
<optgroup label="Other Problem">
<option value="other">other</option>
</optgroup>
</select>
<br><br>
<textarea id="comment" style="resize:none; width:400px; height:200px;" ></textarea>
<br>
<img src="all_icons/loading.gif" width="120" height="120" id="feedback_loading" style="display:none;">
<img src="all_icons/correct-icons-32214-min.png" width="120" height="120" id="feedback_sucess" style="display:none;">
<button id="update_feedback" class="btn btn-primary btn-lg">SEND FEEDBACK</button>
</center>
</div><!--End of the feedback system pc-->
<div id="contactus" style="background:url(all_icons/yellow-vector-background-min-min.png); min-width:600px; min-height:600px; display:none; font-family:playlist; font-size:20px; color:#000;"><!--Start of the contactus modal pc-->
<center><img src="all_icons/asgasmusic logo with site name2-min.png" width="300" height="300" style="border-radius:50%; box-shadow: 0px 0px 20px #000;"></center>Hello,<br> 
Glad to see you're here. Help us by giving your valuable comments. For any queries about our site and anything you want to talk about with us directly go to our feedback page or whatsapp us on +91 9593600154 or mail us on facingproblem@asgasmusic.com .
Thank you!</div><!--End of the contactus modal pc-->
<div id="search_show" style="width:75%; min-width:500px; display:none;" ><!--Start of the search show-->
</div><!--End of the search show-->
<div id="passreset_request" style="background: url(all_icons/yellow-vector-background-452x336-min.jpg);display:none; min-width: 500px;"><!--start of the forget password system-->
<h1 style="font-family:playlist; font-size:18px; text-align:center; color:#000;">Password recovery</h1>
<center><img src="all_icons/icons-about-user-min.png" width="100" height="100" style="margin:10px;"></center>
<div id="line" style="margin-left:-1px;"></div><br>
<div id="txt_passrecover">
<div id="email_passrecver">
<input type="text" class="form-control" id="recoverpassemail" placeholder="ENTER YOUR REGISTERED EMAIL">
</div><br>
<div id="recoverpass">
<center>
<img src="all_icons/loading.gif" width="120" height="120" style="display:none" id="working_recover_email">
<button class="ui-button" id="passrecover">RECOVER NOW!!</button>
</center>
</div>
</div>
</div><!--end of the forget password system-->
<div id="sigup_form" style="display:none; background:url(all_icons/yellow-vector-background-min-min.png) repeat; margin-left: 10%;"><!--Start of the signup form-->
<form action="#" method="get" id="sigup">
<div id="signup" class="signup"><div id="fn" class="form">
<div id="signupheader" style="font: playlist; text-align: center; font-family: playlist; font-size: 25px; color: #000;">SIGNUP FORM</div>
<div id="line"></div>
<div class="lab">FIRST NAME</div>
       <div id="fntxt" class="fn_contain">
       <div class="fn_icon"></div>
       <div class="input_singup_container_fn" id="input_singup_container_fn">
       	<input type="text" placeholder="First name" id="fname" class="normal_signup" name="fname">
       </div>
        </div>
<div class="lab">LAST NAME</div><div id="lntxt" class="ln_contain"><div class="fn_icon"></div>
       <div id="input_singup_container_ln" class="input_singup_container_ln">
       	<input type="text" placeholder="Last name" id="lname" class="normal_signup" name="lname">
       </div>
       </div>
<div class="lab">EMAIL</div><div id="emailtxt" class="em_contain">
      <div class="em_icon"></div>
       <div class="input_singup_container_em" id="input_singup_container_em">
       	<input type="text" placeholder="Email" id="email" class="normal_signup" name="email">
       </div></div>
<div class="lab">PASSWORD</div><div id="pwtxt" class="pss_contain">
      <div class="pss_icon"></div>
       <div class="input_singup_container_pss" id="input_singup_container_pss">
       		<input type="password" placeholder="Password" id="pass" class="normal_signup" name="pass">
       </div></div>
<div class="lab">RETYPE PASSWORD</div><div id="repwtxt" class="pss_contain">
	<div class="pss_icon"></div>
       <div class="input_singup_container_repss" id="input_singup_container_repss">
       	<input type="password" placeholder="Retype Password" id="repass" class="normal_signup">
       </div>
</div>
<div class="lab">MOBILE NUMBER</div><div id="mobtxt" class="mob_contain">
	<div class="mob_icon"></div>
       <div class="input_singup_container_mob" id="input_singup_container_mob">
       	<input type="text" placeholder="MOBILE NUMBER" id="mob" class="normal_signup" name="mob">
       </div>
</div>
<center><div id="sibtn" style="display:block;"><input type="button" name="SignUp" value="SignUp" class="supbuttn" id="singup"></div>
</center>
</div>
</div>
</form>
</div><!--End of the signup form-->
<div id="notification_bar" style="width:80%; min-width:600px; display:none;">
	
</div>
<div id="redeem_money" style="width:80%; min-width:600px; display:none;">
<div class="header_serch_show">REDEEM MONEY</div>
<div id="show_money">
<center><h1 style="font-family:playlist;">Wallet Money Rs:-<?php  include "db.php";
$userid=$_SESSION['userid'];
$sql="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	   $query=mysqli_query($conn,$sql);
	   $fetch=mysqli_fetch_assoc($query);
	   $count=mysqli_num_rows($query);
	   echo $fetch['MoneyEarned'].'</h1>'; ?></center>
</div>

<div id="redeem_money_opt" style="margin-top:10%;">
<center>
<?php
if(isset($_SESSION['userid']))
    {
		$userid=$_SESSION['userid'];
		$sql_redeem_money="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid' ";
		$query_redeem_money=mysqli_query($conn,$sql_redeem_money);
		$fetch=mysqli_fetch_assoc($query_redeem_money);
		$count=mysqli_num_rows($query_redeem_money);
		if($fetch['MoneyEarned']<50)
		{
			echo'<div id="details" class="disabled"><div id="number" style="color:black; font-family:playlist; font-size:50px;">'.
$fetch['mobileNo'].'</div>
<h1 style="font-family:playlist; font-size:20px;">LOW BALANCE UNABLE TO REDEEM NOW.<br><br>YOU NEED MINIMUM &#8377; 52.50</h1>
	  <br><br>
	  <h5 style="font-family:playlist;"><strong>Note:-</strong>5% Charged Will Applied On This Transaction.</h5>
	  <br>
	  <div id="money" style="display:none;" val="'.$fetch['MoneyEarned'].'"></div>
	  <h3 style="font-family:playlist;"><div id="statu"></div></h3>
</div><div id="back"></div>';
			
			
		}
			else if($fetch['MoneyEarned']>=50&&$fetch['MoneyEarned']<52.5)
		{
			echo'<div id="details" class="disabled"><div id="number" style="color:black; font-family:playlist; font-size:50px;">'.
$fetch['mobileNo'].'</div>
<h1 style="font-family:playlist; font-size:20px;">LOW BALANCE UNABLE TO REDEEM NOW.<br><br>YOU NEED MINIMUM &#8377; 52.50</h1>
	  <br><br>
	  <h5 style="font-family:playlist;"><strong>Note:-</strong>5% Charged Will Applied On This Transaction.</h5>
	  <br>
	  <div id="money" style="display:none;" val="'.$fetch['MoneyEarned'].'"></div>
	  <h3 style="font-family:playlist;"><div id="statu"></div></h3>
</div><div id="back"></div>';
			
			
		}	
	else if($fetch['MoneyEarned']>=52.5)
		{
			echo'<div id="details" class=""><div id="number" style="color:black; font-family:playlist; font-size:50px;">'.
$fetch['mobileNo'].'</div>
<select name="recharge_opt" id="recharge_opt" style="height:35px;"  onChange="s()">
<optgroup label="Recharge Option">
        <option value="Paytm" selected="selected">Paytm</option>
		<!--<option value="recharge">recharge</option>--!>
</select><br><br>
<select name="amount" id="amount" style="height:35px;">
      <optgroup label="AMOUNT">
        <option value="50" selected="selected">50</option>
        <option value="100">100</option>
        <option value="150">150</option>
        <option value="200">200</option>
        <option value="250">250</option>
        <option value="300">300</option>
      </optgroup>
      </select>
	  <br><br>
	  <button style="font-family:playlist;" class="ui-button" id="redeem_btn" onClick="redem_now()">REDEEM</button>
	  <br>
	  <div id="money" style="display:none;" val="'.$fetch['MoneyEarned'].'"></div></div><div id="back"></div>
	  <h5 style="font-family:playlist;"><strong>Note:-</strong>5% Charged Will Applied On This Transaction.</h5>
	  ';
    
	$_SESSION['MoneyEarned']=uniqid().$fetch['MoneyEarned'].'-'.uniqid().'-'.$fetch['MoneyEarned'].uniqid().'/'.$fetch['MoneyEarned'].'/'.'-'.uniqid().'-'.uniqid();
	
		}	
			}
?>
<script>
var userid='<?php echo $_SESSION['userid'] ?>';
</script>
<div class="header_serch_show">-:Request:-</div>
<div id="pending_request">
<center><h1 style="font-family:playlist;"><div id="show_pending_request"><div id="fetch" class="loader"><p align="center"><h5 style="position:absolute; top:60%; left:25%;">PLEASE WAIT WHILE WE FETCH YOUR DATA...</h5></p></div></div></h1></center>
</div>
</center>
</div>
</div>
<div id="setting_menu" style="width:80%; min-width:600px; display:none; ">
<div class="header_serch_show">SETTING</div>
<center>
<div id="setting_menu_content" style="min-width:550px; width:100%; min-height:400px; height:100%; padding:20px; border:1px solid #000; margin-top:15px; margin-bottom:15px;">
<center><img src="all_icons/reggae-clipart-cbf299e8fb9244926994ad7db1ecee5bb_p_400-min.png" id="user_icon"></center>
<div id="user_name"><?php echo "<b>".$name."</b>";?>
<div id="data">
<br><br>
<div id="show_data">
<label style=" float:left; padding-left:10px; font-family:playlist; font-size:20px;">Email:-</label><div style="height:40px; width:300px; padding-left:10px; font-family:playlist; font-size:20px; float:right; cursor:not-allowed;"><?php echo $fetch['Email']; ?></div><br><br>
<label style=" float:left; padding-left:10px; font-family:playlist; font-size:20px;">Mobile Number:-</label>
<div style=" height:40px; width:300px; padding-left:10px; font-family:playlist; font-size:20px; float:right; cursor:not-allowed;"><?php echo $fetch['mobileNo']; ?></div>
<br><br>
<label style=" float:left; padding-left:10px; font-family:playlist; font-size:20px;">Change Password:-</label>
<button id="change_pass" onClick="change_pass();" class="ui-button" style="">Update Your Password</button>
<br><br></div>
<div id="chng_pass" style="display:none;">
<label style=" float:left; padding-left:10px; font-family:playlist; font-size:20px; margin:12px;">Current Password:-</label>
<input type="password"  onBlur="curr();" class="bor" placeholder="Current Password" id="cpass" style="width:200px; height:35px; padding:07px; margin:10px; font-family:playlist; font-size:16px; float:right; border-radius:10px;">
<br><br>
<label style=" float:left; padding-left:10px; font-family:playlist; font-size:20px; margin:12px;">New Password:-</label>
<input type="password" onBlur="newp();" class="bor" placeholder="New Password" id="npass" style="width:200px; height:35px; padding:07px; margin:10px; font-family:playlist; font-size:16px; float:right; border-radius:10px;">
<br><br>
<label style=" float:left; padding-left:10px; font-family:playlist; font-size:20px; margin:12px;">Retype new Password:-</label>
<input type="password" onBlur="renew();"  class="bor"placeholder="Retype new Password" id="cnpass" style="width:200px; height:35px; padding:07px; margin:10px; font-family:playlist; float:right; font-size:16px; border-radius:10px;">
<br><br>
<button type="button" id="update" class="ui-button" style=" margin-left:40%;" onClick="newpass()">Update</button>
<br><br><br>
<button type="button" id="back" class="ui-button" onClick="back00()" style="margin-left:-22px;">Back</button>
<div id="fetch_pass" class="loader"></div>
</div>
</div>
</div>
</div>
</center>
	</div>
<div id="aboutus_modal" style="display: none; min-width: 600px; min-height: 500px; font-family: playlist; font-size: 20px; background:url(all_icons/yellow-vector-background-min-min.png); color:#000;"><center><img src="all_icons/asgasmusic logo with site name2-min.png" width="300" height="300" style="border-radius:50%; box-shadow: 0px 0px 20px #000;"><!--start about us-->
	</center>
	  <p>As the name suggests Asgasmusic is a music site but not as the other available sites on Internet! Here we provide you the opportunity of earning! Yes, earning by downloading! To earn money you need to sign up in our site with the phone number registered in your paytm account. We provide the money on the basis of each song you are downloading after logging in. 
    Our goal is to provide you the best and set a goodwill gesture of ASGAS in public!.
    </p></div><!--End about us-->

<div id="earn_ads_show" style="display: none" class="earn_ads_show"><!--Start of the ads Showing Div-->
<center>
<h1 style="font-family:playlist; font-size:16px; color: crimson;">DON'T CLOSE ANY NEW TAB FOR '9' SEC IF IT OPEN.<br>PLEASE CLICK IN ADS TO GET YOUR REWARD AND DOWNLOAD THE SONG.</h1><br>
<center><div id="showing-ads">
<?php
if(isset($_SESSION['userid']))
{
	include("db.php");
	$date=date('y-m-d');
	$str_date__=strtotime($date);
	$userid=$_SESSION['userid'];
	$sql="SELECT * FROM `user-shown-ads` WHERE `userid`='$userid' AND `date`='$str_date__'";
	$query=mysqli_query($conn,$sql);
	$count=mysqli_num_rows($query);
	$fetch_count=mysqli_fetch_assoc($query);
	$count__=($fetch_count['ads-id']*1);
	if($count>0)
	{
		if($count>=16)
		{
			echo("Your Earning Limit Is Over For Today.");
		}
		else
		{
                        $date=date('y-m-d');
	$str_date__=strtotime($date);
	$userid=$_SESSION['userid'];
	$sql="SELECT * FROM `user-shown-ads` WHERE `userid`='$userid' AND `date`='$str_date__'";
	$query=mysqli_query($conn,$sql);
	$count=mysqli_num_rows($query);
	$fetch_count=mysqli_fetch_assoc($query);
			$shown_ads=($count+1);
			$sql="SELECT * FROM `ads-fetch_300x250` WHERE `id`='$shown_ads'";
	        $query=mysqli_query($conn,$sql);
	        $count=mysqli_num_rows($query);
			$fetch=mysqli_fetch_assoc($query);
			$ads_id=$fetch['id'];
			echo($fetch['ads-fetch_300x250'].'<input type="text" value="'.$userid.'" id="userid" hidden="hidden"><br><input type="text" value="'.$ads_id.'" id="count" hidden="hidden"><br><input type="text" value="'.$str_date__.'" id="date" hidden="hidden">');
			
		}
	}
		else
		{
			$shown_ads=($count+1);
			$sql="SELECT * FROM `ads-fetch_300x250` WHERE `id`='$shown_ads'";
	        $query=mysqli_query($conn,$sql);
	        $count=mysqli_num_rows($query);
			$fetch=mysqli_fetch_assoc($query);
			$ads_id=$fetch['id'];
			echo($fetch['ads-fetch_300x250'].'<input type="text" value="'.$userid.'" id="userid" hidden="hidden"><br><input type="text" value="'.$ads_id.'" id="count" hidden="hidden"><br><input type="text" value="'.$str_date__.'" id="date" hidden="hidden">');
			
		}
	
}
else{
	echo("not working.");
}

?>
</div></center>
<div id="loader-ads-earn"></div>
<h1 style="font-family:playlist; font-size:16px; cursor:pointer;" id="nonereward" class=".shadow00">CLICK HERE TO DOWNLOAD ONLY SONG(NO REWARDED).</h1><br>
<h1 style="font-family:playlist; font-size:16px;">PLEASE CLICK IN ANY ADS TO EARN REWARD AND DWONLOAD YOUR SONG.</h1>
</center>
</div><!--End of the ads Showing Div-->
<script src="js/main.js"></script><!--Start of the script file-->
<script src="audioplayerengine/amazingaudioplayer.js"></script>
<script src="audioplayerengine/initaudioplayer-1.js"></script>
<script src="js/jquery.modal.min.js"></script>
<script src="js/search.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/signup form.js"></script>
<script src="js/notification.js"></script>
<script src="js/login_user_and_showing.js"></script>
<script src="js/toastr.js"></script>

<script>
var userid='<?php echo $_SESSION['userid'] ?>';
</script>

<script src="js/redeem.js"></script><!--End of the script file-->
<!--adblocker blocker start-->
<style>.amazingaudioplayer-source{display:none}#v83b{position:fixed !important;position:absolute;top:0px;top:expression((t=document.documentElement.scrollTop?document.documentElement.scrollTop:document.body.scrollTop)+"px");left:0px;width:101%;height:100%;background-color:#fff;opacity:.95;filter:alpha(opacity=95);display:block;padding:20% 0}#v83b *{text-align:center;margin:0 auto;display:block;filter:none;font:bold 14px Verdana,Arial,sans-serif;text-decoration:none}#v83b ~ *{display:none}</style><div id="v83b"><div>Please enable / Bitte aktiviere JavaScript!<br>Veuillez activer / Por favor activa el Javascript!<a href="music show.php"><button class="ui-button">I Have Disabled My Adblocker.Please Reload The Page</button></a></div></div><script>window.document.getElementById("v83b").parentNode.removeChild(window.document.getElementById("v83b"));(function(l,m){function n(a){a&&v83b.nextFunction()}var h=l.document,p=["i","s","u"];n.prototype={rand:function(a){return Math.floor(Math.random()*a)},getElementBy:function(a,b){return a?h.getElementById(a):h.getElementsByTagName(b)},getStyle:function(a){var b=h.defaultView;return b&&b.getComputedStyle?b.getComputedStyle(a,null):a.currentStyle},deferExecution:function(a){setTimeout(a,2E3)},insert:function(a,b){var e=h.createElement("div"),d=h.body,c=d.childNodes.length,g=d.style,f=0,k=0;if("v83b"==b){e.setAttribute("id",b);g.margin=g.padding=0;g.height="100%";for(c=this.rand(c);f<c;f++)1==d.childNodes[f].nodeType&&(k=Math.max(k,parseFloat(this.getStyle(d.childNodes[f]).zIndex)||0));k&&(e.style.zIndex=k+1);c++}e.innerHTML=a;d.insertBefore(e,d.childNodes[c-1])},displayMessage:function(a){var b=this;a="abisuq".charAt(b.rand(5));b.insert("<"+a+'><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjcAAAAiBAMAAABRguWcAAAAD1BMVEX9/f3IyMgAAADIyMgAAADJAn4jAAAE1ElEQVRoge1WCa7cIAwlywHCnCDhBJGYA0Qa7n+m+tkGTJa/VO3XVI0nisDrw7HNOHfTTTf9aQohzK4PH2j0Mx67hdl8qntufm4VTtTejIL3hDJM1xr9gsduy/srZPUbqzbm1x3+IBFEeS4JsH27/f+SE6iCenr10mizyPtAsLEJkJOoX7DDWbKO9B0ssQjFVPzktDRWEIWJHcIkvGtyQlg4Of3yIMD+MXOjBa8jgRaLdBaJ6EVn7/QsWYelMJdFZYsfSU5jJaLHMklQvN4zOd57qR9PI7IjuLTugHuGuMcB8tjx9AsiYk7RQWGQSLM0ddIwqrxkP9WKlLspwARBA/y+Z3ImfVMJUaFTHaGteiwgqJkJ0nF03sxsdODhIclRz1XZ+snKcJiDTu5d26okh0roQb2zOGorqnvPQ7gmp9OOq8lpdI7JqcruPDncxt7/C8nBTMXsXfhmD/mPB1W9nGjmQ/XhwX3AtWR1epo4Ey9KckiZOdj0xip4xMpBgkLw7v1IPpvcIHS6gIlKix4TwTm5rfj+ogbwpEfFwBNcrraq47Bh5dpWM/JTbqtixQuKNfEdt2jlzD9+9M9Jhif6o6NX5yeajthRuYtC5nTgeN9NvmPlqej0Ds0oHChn11BmDm+MlcYiYV6496ycP0Ehl9BNR+pKmd1000033XTTTT9MiR+73cnTgaU0kmjbc4jRMNl4bNUOQXfxNnJ0BVdCWIeyNkHThyFUerA6VU8rnhp7a8XjKz53LCOKcc9JeLfud5xj0FYU4eNKehJC1oYjthch9IDpubc6jdk6SXGXP5hHd0qHI4NDX+Qk4t7DuI2vq+SsH6VOQ1iHF8m5CKEH/E5ycsGQv3FLIxd25rBSomD0ggjH344i5aTIfDZHB6Q1cfWSDpymUaNCD+JDNdfkwOkI96nFgyib9juJxhc3Wgm66SFtCIOQDgid586qQDXHQQ7JWy4YDj1iV0oIGMYXtVaiF0QCz2n7F5Fy6GtBCnPuAELBnDENcPpU5PiqHOZQJIl9pFU9U1NzozUI5SERQrBnE/Q0REHIBySd585KoTbH4QJjrrVdh8JxA8NzgOeiiEol08gpIuUkdYIKjG5Y8f0qZ82lXjmH5PAgAx+eB7Kg9dAi1MchrII3QdNJiIqQnnRmJVCb42hy8Ln006eX1Jpy2KH4X7UMa3JyF+TzlZkjGFYuhNUZTm5yo7NPThmnRCvjQe8UhCUzSTouPUu6oFMdNiEKwqzzNEk2UCVoQZTYv947qFVJjrmJvpecfURUaOaMXEdfTQ4heAKPi+jlgjADGLTjzDFJ57PkwOFVcriNY7TJQZMm17QV2JmDSuDJn5ODuqvJKSLl6EBGbWLyyZQrGChy0VSdMZ9l2yUH5nD44pvdIJQQDAxXyTPVoOSuOrQhms8HjrUyUHWR8XCT5k9ak1M+cuJW1FZWkb09U+1yHchyy/ACeQMU3ClSOVtNjujUy8UkR28QMk9s9aoIdbMxsFHunRIUWDaTnBKire2dlYGqi4xnWPHkTxplymGlnAGLIbIWy0cX5U+C6BWRGEXhOFlE9s1seJY/eMVWdIZ6uTjB44x5XMW8IpRNFGCRzONQg67VYROiIsQz7KwMVF1UPN+kVCbHd0kq64J+0+dfI8LzCzsuaq8Bqi74AAAAAElFTkSuQmCC" height="34" width="567" alt="" /> <a href="music show.php"><button class="ui-button">I Have Disabled My Adblocker.Please Reload The Page</button></a>'+("</"+a+">"),"v83b");h.addEventListener&&b.deferExecution(function(){b.getElementBy("v83b").addEventListener("DOMNodeRemoved",function(){b.displayMessage()},!1)})},i:function(){for(var a="ad_Pushdown,adlink-28,ads-lrec,adv728x90,advert-120,iqadtile11,weatherad,ad,ads,adsense".split(","),b=a.length,e="",d=this,c=0,g="abisuq".charAt(d.rand(5));c<b;c++)d.getElementBy(a[c])||(e+="<"+g+' id="'+a[c]+'"></'+g+">");d.insert(e);d.deferExecution(function(){for(c=0;c<b;c++)if(null==d.getElementBy(a[c]).offsetParent||"none"==d.getStyle(d.getElementBy(a[c])).display)return d.displayMessage("#"+a[c]+"("+c+")");d.nextFunction()})},s:function(){var a={'pagead2.googlesyndic':'google_ad_client','js.adscale.de/getads':'adscale_slot_id','get.mirando.de/miran':'adPlaceId'},b=this,e=b.getElementBy(0,"script"),d=e.length-1,c,g,f,k;h.write=null;for(h.writeln=null;0<=d;--d)if(c=e[d].src.substr(7,20),a[c]!==m){f=h.createElement("script");f.type="text/javascript";f.src=e[d].src;g=a[c];l[g]=m;f.onload=f.onreadystatechange=function(){k=this;l[g]!==m||k.readyState&&"loaded"!==k.readyState&&"complete"!==k.readyState||(l[g]=f.onload=f.onreadystatechange=null,e[0].parentNode.removeChild(f))};e[0].parentNode.insertBefore(f,e[0]);b.deferExecution(function(){if(l[g]===m)return b.displayMessage(f.src);b.nextFunction()});return}b.nextFunction()},u:function(){var a=".mx/ads/,/bansrc/ad,/bbad.,/content/ad/ad,/dfp-custom/ad,/images/ad2/ad,/product-ads/ad,_ad_over_,_dynamicads/,/180x150-".split(","),b=this,e=b.getElementBy(0,"img"),d,c;e[0]!==m&&e[0].src!==m&&(d=new Image,d.onload=function(){c=this;c.onload=null;c.onerror=function(){p=null;b.displayMessage(c.src)};c.src=e[0].src+"#"+a.join("")},d.src=e[0].src);b.deferExecution(function(){b.nextFunction()})},nextFunction:function(){var a=p[0];a!==m&&(p.shift(),this[a]())}};l.v83b=v83b=new n;h.addEventListener?l.addEventListener("load",n,!1):l.attachEvent("onload",n)})(window);</script>
<!--adblocker blocker end-->
</body><!--End of the Body-->

</html>