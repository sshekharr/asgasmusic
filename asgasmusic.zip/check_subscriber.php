<?php
if(isset($_POST['userid']))
   {
	   include"db.php";
	   $userid=$_POST['userid'];
	   $sql="SELECT * FROM `subcriber` WHERE `userid`='$userid'";
	   $query=mysqli_query($conn,$sql);
	   $count=mysqli_num_rows($query);
	   if($count>0)
	      {
			  echo 100;
		  }
	    else
		  {
			  echo 000;
		  }
   }
?>