<?php
include "db.php";

	   $fname=$_POST['frname'];
	   $lname=$_POST['laname'];
	   $email=strtolower($_POST['Email']);
	   $pass1=$_POST['Pass'];
	   $salt='A_M';
	   $pass_crypt=sha1(crypt(md5($pass1),$salt));
	   $mob=$_POST['Mob'];
	   $id=uniqid();
	   $uniId=uniqid();
	   $id1=$id.'.'.$uniId;
	   $Ip=$_SERVER['REMOTE_ADDR'];
	   date_default_timezone_set("Asia/kolkata");
	   $timezone=date_default_timezone_get();
	   $dates=date('d/m/y H:i:s a',time());
	   
				$sql="INSERT INTO `login-&-signup-data`(`randomId`, `FirstName`, `LastName`, `Email`, `Password`, `mobileNo`, `act-block`, `MoneyEarned`, `MoneyRedeemed`, `EmailActivation`, `Ip`, `SingupDate`,`uniId`) VALUES ('$id','$fname','$lname','$email','$pass_crypt','$mob',1,5,0,0,'$Ip','$dates','$uniId')";
				if($query=mysqli_query($conn,$sql))
{
				   
require("class.phpmailer.php");

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "bh-ht-3.webhostbox.net";

$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Port = 465;
$mail->Username = "noreply@asgasmusic.com";
$mail->Password = "asgasmusic@2016";

$mail->From = "noreply@asgasmusic.com";
$mail->FromName = "Asgasmusic";
$mail->AddAddress($email);
//$mail->AddReplyTo("mail@mail.com");

$mail->IsHTML(true);

$mail->Subject = "AsgasMusic email confirmation";
$mail->Body = "<h1'>Please Complete Your Verification By Clicking In Given Link.</h1><br>http://www.asgasmusic.com/verificationpage.php?username=$fname.$lname&email=$email&mobileNo=$mob&id=$id1";




if(!$mail->Send())
{
echo "SignUp Failed Please Refresh The Page And Try Again.";
	$sql_delet="DELETE FROM `login-&-signup-data` WHERE `randomId`='$id'";
	mysqli_query($conn,$sql_delet);
exit;
}

echo "SignUp Complete!!.Please Complete The SignUp procedure By clicking The link Which We send In Your Given Mail Address. Please Check Your Spam Also.";
}
?>