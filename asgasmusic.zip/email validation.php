<?php
include"db.php";
if(isset($_POST['email']))
    {
		$email=$_POST['email'];
		if(filter_var($email,FILTER_VALIDATE_EMAIL))
		    {
				$sql="SELECT * FROM `login-&-signup-data` WHERE `Email`='$email'";
				$query=mysqli_query($conn,$sql);
				$count=mysqli_num_rows($query);
				if($count==0)
				  echo 000;
				else
				  echo 111;  
				
			}
		else
		  echo 222;	
	}
?>
