<?php
if(isset($_POST['email']))
  {
	  $key=uniqid();
	  $email=strtolower($_POST['email']);
      
require("class.phpmailer.php");

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "bh-ht-3.webhostbox.net";

$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Port = 465;
$mail->Username = "noreply@asgasmusic.com";
$mail->Password = "asgasmusic@2016";

$mail->From = "noreply@asgasmusic.com";
$mail->FromName = "Asgasmusic";
$mail->AddAddress($email);
//$mail->AddReplyTo("mail@mail.com");

$mail->IsHTML(true);

$mail->Subject = "REQUEST FOR PASSWORD RESET";
$mail->Body = "Please Enter Click On This Link To reset Your Password.<br> http://www.asgasmusic.com/passreset_user.php?token=$key&email=$email";




if(!$mail->Send())
{
echo 010;
exit;
}

		  
                 include "db.php";
		//fetching the data
		$sql_fetch="SELECT * FROM `login-&-signup-data` WHERE `Email`='$email'";
		$query_fetch=mysqli_query($conn,$sql_fetch);
		$fetch_fetch=mysqli_fetch_assoc($query_fetch);
		$id=rand();
		$uniId=$fetch_fetch['uniId'];
		$userid=$fetch_fetch['randomId'];
		//insert for token key
		$sql_insert="INSERT INTO `token-request`(`Randomid`, `user-uniId`, `tokenid`,`userid`) VALUES('$id','$uniId','$key','$userid')";
		$query_insert=mysqli_query($conn,$sql_insert);


		
		echo 100;

	
  }
// end of the mail a token key 
  
  
  
  
?>