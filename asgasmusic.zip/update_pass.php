<?php
sleep(3);
session_start();
session_regenerate_id();
include "db.php";
if(isset($_POST['pass'])&&isset($_POST['npass'])&&isset($_POST['renpass'])&&isset($_SESSION['userid']))
  {
	  $pass=$_POST['pass'];
	  $salt='A_M';
	  $pass_crypt=sha1(crypt(md5($pass),$salt));
	  $npass=$_POST['npass'];
	  $npass_crypt=sha1(crypt(md5($npass),$salt));
	  $userid=$_SESSION['userid'];
	  $sql="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid' AND `Password`='$pass_crypt'";
	  $query=mysqli_query($conn,$sql);
	  $count=mysqli_num_rows($query);
	  if($count>0)
	      {
			  $sql_update="UPDATE `login-&-signup-data` SET `Password`='$npass_crypt' WHERE `randomId`='$userid' AND `Password`='$pass_crypt'";
			  $query_update=mysqli_query($conn,$sql_update);
			  echo 000;
		  }
	  else
	      {
			  echo 111;
		  }
  }
?>