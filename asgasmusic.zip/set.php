<?php
if(isset($_GET['pass'])&&isset($_GET['repass'])&&isset($_GET['userid'])&&isset($_GET['email'])&&$_GET['pass']===$_GET['repass'])
    {
		 include "db.php";
		$pass=$_GET['pass'];
		$salt='A_M';
	    $pass_crypt=sha1(crypt(md5($pass),$salt));
		$email=strtolower($_GET['email']);
		$userid=$_GET['userid'];
		$sql="SELECT * FROM `login-&-signup-data` WHERE `Email`='$email' AND `randomId`='$userid'";
		$query=mysqli_query($conn,$sql);
		if(mysqli_num_rows($query)>0)
		     {
				 $sql_update="UPDATE `login-&-signup-data` SET `Password`='$pass_crypt'";
				 $query_update=mysqli_query($conn,$sql_update);
				 echo"<script>alert('password updated')</script>";
				 $sql_delet="DELETE FROM `token-request` WHERE `userid`='$userid'";
				 $query_delet=mysqli_query($conn,$sql_delet);
				 sleep(5);
				 header('location:http://www.asgasmusic.com');
				 
				 
			 }
	}
  else
    {
		echo "Please Input The Correct Data.";
	}
?>