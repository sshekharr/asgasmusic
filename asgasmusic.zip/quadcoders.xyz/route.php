<?php

$a=file_get_contents("https://api.tiles.mapbox.com/v4/directions/mapbox.driving/1.79901123046875,49.09185510395163;2.43896484375,48.42373281900577.json?instructions=html&geometry=polyline&access_token=pk.eyJ1IjoidW5pdGVkYnloY2wiLCJhIjoiY2oyMnU5aW50MDAxcTM0bzdrZWd6d2F2ayJ9.A35fLnzsn18JyajVXY3few");
$d=json_decode($a);
print_r($d);
?>
