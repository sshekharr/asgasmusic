<?php
$pass="quadcoders@2017";
$servername="localhost";
$username="asgasmus_quadcod";
$conn=mysqli_connect($servername,$username,$pass,'asgasmus_all_quadcoders_content') or die("Error in connection with data base of login user");
?>

