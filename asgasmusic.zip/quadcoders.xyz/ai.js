// JavaScript Document
$(document).ready(function(e) {
    setInterval(function(){
	    var voice_command_activated=$.cookie('Is_ai_start'),img;
		img=$("#ai_img");
		   if(voice_command_activated==1)
		   		{
					img.attr("src","icon_content/microphone.png");
				}
			else if(voice_command_activated==0)
			    {
					img.attr("src","icon_content/muted.png");
				}
				
			else
			   {
				   img.attr("src","icon_content/microphone (1).png");
			   }
			   
				
	},250);
});
var ai="",Is_ai_start,voiceMap = [],mapExpand=$.cookie("openMap",0),searchExpand=$.cookie("opensearch",0);
	//commands
		var commands={		
		//search type
			'search type *val':function(val){
							searchExpand=$.cookie("opensearch");
				          if(searchExpand==1&& $.cookie('Is_ai_start')==1)
						   		{
									$("#search_txt").val(val);
								}
						else if($.cookie('Is_ai_start')==1)
						      {
								  $("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val(val);
							  }
				},	
				'type *val':function(val){
							searchExpand=$.cookie("opensearch");
				          if(searchExpand==1&& $.cookie('Is_ai_start')==1)
						   		{
									$("#search_txt").val(val);
								}
						else if($.cookie('Is_ai_start')==1)
						      {
								  $("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val(val);
							  }
				},	
				'baby type *val':function(val){
							searchExpand=$.cookie("opensearch");
				          if(searchExpand==1&& $.cookie('Is_ai_start')==1)
						   		{
									$("#search_txt").val(val);
								}
						else if($.cookie('Is_ai_start')==1)
						      {
								  $("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val(val);
							  }
				},	
				'Anna type *val':function(val){
							searchExpand=$.cookie("opensearch");
				          if(searchExpand==1&& $.cookie('Is_ai_start')==1)
						   		{
									$("#search_txt").val(val);
								}
						else if($.cookie('Is_ai_start')==1)
						      {
								  $("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val(val);
							  }
				},'baby search *val':function(val){
							searchExpand=$.cookie("opensearch");
				          if(searchExpand==1&& $.cookie('Is_ai_start')==1)
						   		{
									$("#search_txt").val(val);
								}
						else if($.cookie('Is_ai_start')==1)
						      {
								  $("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val(val);
							  }
				},	
				'Anna search *val':function(val){
							searchExpand=$.cookie("opensearch");
				          if(searchExpand==1&& $.cookie('Is_ai_start')==1)
						   		{
									$("#search_txt").val(val);
								}
						else if($.cookie('Is_ai_start')==1)
						      {
								  $("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val(val);
							  }
				},
				'search *val':function(val){
							searchExpand=$.cookie("opensearch");
				          if(searchExpand==1&& $.cookie('Is_ai_start')==1)
						   		{
									$("#search_txt").val(val);
								}
						else if($.cookie('Is_ai_start')==1)
						      {
								  $("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val(val);
							  }
				},		
				// other command
		'*val':function(val){
					val = val.toLowerCase();
			     //reload
				 if((val=='baby reload'||val=='reload baby'|| val=='reload'||val=='refresh'||val=='reload Anna'||val=='Anna reload' )&& $.cookie('Is_ai_start')==1)
				         {
							location.reload();
							$.cookie("openMap",0);
							$.cookie("opensearch",0);
						 }
			    //activating voice command
				if(val=='wake up baby'||val=='baby wake up'||val=='Anna wake up'||val=='wake up Anna')
						 {
							 if($.cookie('Is_ai_start')==1)
								   {
									   speak("Im Already Here.");
								   }
								   else
								   {
								$.cookie('Is_ai_start',1);
								console.log("voice commands activated");console.log($.cookie('Is_ai_start')); 
								
									}
						 }
				//deactivating voice command
			    if(val=='take some rest baby'||val=='baby take some rest'||val=='Anna take some rest'||val=='take some rest Anna')
						 {
							 	$.cookie('Is_ai_start',0);
								console.log("voice commands deactivated");console.log($.cookie('Is_ai_start')); 
								speak("Ok. See you later.");
						 }
				if(val=='next' && $.cookie('Is_ai_start')==1)
						{
							next();
						}		//close tour
				if((val=='close'|| val=='no') && $.cookie('Is_ai_start')==1)
						{
							close_();
						}
					// take tour again
				if(val=='yes' && $.cookie('Is_ai_start')==1)
						{
							start();
						}
				if( $.cookie('Is_ai_start')==1&&(val=='tour'||val=='baby open tour'||val=='Anna open tour'||val=='open tour'))
						{
							tour___();
						}
						//wakeup
				if(val=='wake up' && $.cookie('Is_ai_start')==1)
						{
							if($.cookie('Is_ai_start')==1)
								   {
									   speak("Im Already Wake Up.");
								   }
								   else
								   {
								$.cookie('Is_ai_start',1);
								console.log("voice commands activated");console.log($.cookie('Is_ai_start')); 
								speak("hi. What can I do for you?");
									}
								
						}
						//developer
				if((val=='who is your developer'||val=='who developed you'||val=='Anna who developed you'||val=='Anna who is your developer'||val=='who developed you baby'|| val=='baby who developed you'||val=='who is your developer baby' || val=='baby who is your developer'||val=='who developed you Anna')&&$.cookie('Is_ai_start')==1)
				        {
							speak("Team Quadcoders.");
						}
				if((val=='baby'||val=='Anna')&& $.cookie('Is_ai_start')==1)
				     {
						 speak("hi. How can I Help you?");
					 }
					 
					 //tour next
				if((val=='go to next' ||val=='Anna go to next'||val=='baby go to next'||val=='click next'||val=='Anna click next' ||val=='baby click next'||val=='Anna go to next')&&$.cookie('Is_ai_start')==1)
						{
							next();
						}		//close tour
				if((val=='go to close'|| val=='no' ||val=='Anna go to close'||val=='baby go to close'||val=='click close'||val=='Anna click close'||val=='baby click close'||val=='Anna close tour'||val=='close tour')&&$.cookie('Is_ai_start')==1)
						{
							close_();
						}
					// take tour again
				if((val=='go to yes'||val=='Anna go to yes'||val=='baby go to yes'||val=='click yes'||val=='Anna click yes'||val=='baby click yes'||val=='Anna go to yes'|| val=='yes')&&$.cookie('Is_ai_start')==1)
						{
							start();
						}
						//open map
				if((val=='open map'||val=='expand map' ||val=='show me map baby'||val=='baby open map'||val=='baby show me map'||val=='open map baby'|| val=='show me map'||val=='Anna open map'||val=='open map Anna'||val=='Anna expand map'||val=='expand map Anna'||val=='show me map Anna'||val=='Anna show me map')&&$.cookie('Is_ai_start')==1)
				        {
							mapExpand=$.cookie("openMap")
							if(mapExpand==0)
							    {
									$.cookie("openMap",1);
									expand();
									
								}
							else{
									speak("Map is already opened.");
								}
						}
						//close map
				if((val=='close map'||val=='close map baby'||val=='baby close map'||val=='minimise map'||val=='minimise map baby'||val=='baby minimise map'||val=='Anna close map'||val=='close map Anna'||val=='Anna minimise map'||val=='minimise map Anna')&&$.cookie('Is_ai_start')==1)
				       {
						   mapExpand=$.cookie("openMap");
						   if(mapExpand==1)
						     {
						  		 minimize();
								 $.cookie("openMap",0);
							 }
							else
							  {
								  speak("Map is already closed.");
							  }
								 
					   }
				if((val=='show me washrooms'||val=='baby show me washrooms'||val=='show me washrooms baby'||val=='show me washroom'||val=='baby show me washroom'||val=='show me washroom baby'||val=='search washrooms'||val=='baby search washrooms'||val=='search washrooms baby'||val=='search washroom'||val=='baby search washroom'||val=='search washroom baby'||val=='washrooms'||val=='washroom')&&$.cookie('Is_ai_start')==1)
				      {
						  mapExpand=$.cookie("openMap")
						  if(mapExpand==1)
							    {
									toilet_pointers();
								}
						  else
								{
									expand();
									toilet_pointers();
								}
				
					  }
				if((val=='show me near me washrooms'||val=='baby show me near me washrooms'||val=='show me near me washrooms baby'||val=='show me near me washroom'||val=='baby show me near me washroom'||val=='show me near me washroom baby'||val=='search near me washrooms'||val=='baby search near me washrooms'||val=='search near me washrooms baby'||val=='search near me washroom'||val=='baby search near me washroom'||val=='search near me washroom baby'||val=='near me washrooms'||val=='near me washroom'||val=='washrooms near me')&&$.cookie('Is_ai_start')==1)
				      {
						  mapExpand=$.cookie("openMap");
						  if(mapExpand==1)
							    {
									near_me_toilets();
								}
						  else
								{
									expand();
									near_me_toilets();
								}
					  }
				if((val=='search'||val=='baby open search'||val=='Anna open search'||val=='baby focus on search'||val=='Anna focus on search')&& $.cookie('Is_ai_start')==1)
					{
						
						searchExpand=$.cookie("opensearch");
						if(searchExpand==0)
						   {
									$("#search_txt").focus();
									$.cookie("opensearch",1);
									$("#search_txt").val('');
						   }
						   else
						   {
							   speak("Search is already Opened.");
						   }
					}
				if((val=='exit search'||val=='focusout search'||val=='focus out search'||val=='baby close search'||val=='Anna close search'||val=='baby focusout on search'||val=='Anna focusout on search'||val=='Anna exit search'||val=='baby exit search')&& $.cookie('Is_ai_start')==1)
					{
						searchExpand=$.cookie("opensearch");
						if(searchExpand==1)
						   {
									$("#search_txt").blur();
									search_close();
									searchFocusOut();
									$.cookie("opensearch",0);
									$("#search_txt").val('');
						   }
						   else
						   {
							   speak("Search is already FocusOut.");
						   }
						
					}
				
				
			},
			
			
		
		}
	//Getting Permission From User
	annyang.addCommands(commands);
	annyang.setLanguage('en-IN');
	annyang.debug();
	annyang.start();
	//voice of ai
	function loadVoices () {
				var voices = speechSynthesis.getVoices();
				for (var i = 0; i < voices.length; i++) {
					var voice = voices[i];
					voiceMap[voice.name] = voice;
				};
			};

			window.speechSynthesis.onvoiceschanged = function(e){
				loadVoices();
			};
	function speak (msgtxt) {
				var msg = new SpeechSynthesisUtterance();
				msg.volume = 1;
				msg.voice = voiceMap['Veena'];
				msg.rate = 0.65;
				msg.Pitch = 1.3;
				msg.text = msgtxt;
				window.speechSynthesis.speak(msg);
			};


