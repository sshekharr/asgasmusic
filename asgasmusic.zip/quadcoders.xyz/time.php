<?php
$data= file_get_contents('');
	$array=array($data);
	print_r($array);
	echo $array[0]['dayofweek'];

?>