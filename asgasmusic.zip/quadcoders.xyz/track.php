<?php
if(isset($_GET['data']))
    {
		sleep(5);
		include"db.php";
		
		$data=json_decode($_GET['data']);
		$length=sizeof($data->members)-1;
		$members=array();
		$own=$data->members[0];
		$lat=$data->mem1_lat;
		$lon=$data->mem1_lon;
		$id=uniqid();
		for($i=1;$i<=$length;$i++)
			{
				$members[$i]=$data->members[$i];
				$members[$i]=$members[$i];
				
			}
			$allinone= implode('/@/',$members);
			$sql="INSERT INTO `tracking_members`(`uniqid`,`own_email_number`, `friends`, `own_lat`, `own_lon`, `count`) VALUES('$id','$own','$allinone','$lat','$lon','$length')";
			if (mysqli_query($conn, $sql)) {
								echo json_encode("New record created successfully.-".$id);
								
							}
			else
					{
						echo json_encode('error in upload data');
					}
			
			
	}
	if(isset($_GET['location']))
			{
				include"db.php";
				$data_update=json_decode($_GET['location']);
				$lat_update=$data_update->lat;
				$lon_update=$data_update->lon;
				$uniqid=$data_update->id;
				$sql_update="UPDATE `tracking_members` SET `own_lat`='$lat_update',`own_lon`='$lon_update' WHERE `uniqid`='$uniqid'";
				if(mysqli_query($conn, $sql_update))
				     {
						 echo json_encode("updated");
					 }
				else {
							echo json_encode("Error updating");
						}
			}
	if(isset($_GET['data_userid']))
				{
					include"db.php";
					$userid=json_decode($_GET['data_userid']);
					$userid=$userid->userid;
					$sql="SELECT * FROM `tracking_members` WHERE `uniqid`='$userid'";
					$query=mysqli_query($conn,$sql);
					$fetched_data=mysqli_fetch_assoc($query);
					$friends=$fetched_data['friends'];
					$output=array();
					$output[0]['lat']=$fetched_data['own_lat'];
					$output[0]['lon']=$fetched_data['own_lon'];
					$output[0]['name']=$fetched_data['own_email_number'];
					$frnd_split=explode('/@/',$friends);
					$i=1;
					foreach($frnd_split as $frnds)
							{
								$sql_frnds="SELECT * FROM `tracking_members` WHERE `own_email_number` = '$frnds'";
								$sql_frnds_query=mysqli_query($conn,$sql_frnds);
								$fetched_frnds_data=mysqli_fetch_assoc($sql_frnds_query);
								$output[$i]['lat']=$fetched_frnds_data['own_lat'];
								$output[$i]['lon']=$fetched_frnds_data['own_lon'];
								$output[$i]['name']=$fetched_frnds_data['own_email_number'];
								$i++;
							}
					echo json_encode($output);
					
				}
?>