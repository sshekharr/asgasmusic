<?php
include "db.php";
$date_day=date('y-m-d');
$date=strtotime($date_day);
$sql_count="SELECT * FROM `pagecount` WHERE `date`='$date'";
$query_count=mysqli_query($conn,$sql_count);
$count_count=mysqli_num_rows($query_count);
if($count_count>0)
    {
		$fetch_count=mysqli_fetch_assoc($query_count);
		$view_update=$fetch_count['view'];
		$sum=$view_update+1;
		$sql_update="UPDATE `pagecount` SET `view`='$sum'";
		$query_update=mysqli_query($conn,$sql_update);
		
	}
else
    {
		$sql_insert="INSERT INTO `pagecount`(`view`, `date`) VALUES ('1','$date')";
		$query_insert=mysqli_query($conn,$sql_insert);
	}
?>