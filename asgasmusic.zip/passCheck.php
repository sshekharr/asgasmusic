<?php
include "db.php";

	   $pass=$_POST['pass'];
	   echo $pass;
  
?>