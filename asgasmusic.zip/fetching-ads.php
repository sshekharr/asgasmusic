<?php
session_start();
if(isset($_SESSION['userid']))
{
	include("db.php");
	$date=date('y-m-d');
	$str_date__=strtotime($date);
	$userid=$_SESSION['userid'];
	$sql="SELECT * FROM `user-shown-ads` WHERE `userid`='$userid' AND `date`='$str_date__'";
	$query=mysqli_query($conn,$sql);
	$count=mysqli_num_rows($query);
	$fetch_count=mysqli_fetch_assoc($query);
	$count__=($fetch_count['ads-id']*1);
	if($count>0)
	{
		if($count>=16)
		{
			echo("Your Earning Limit Is Over For Today.");
		}
		else
		{
                        $date=date('y-m-d');
	$str_date__=strtotime($date);
	$userid=$_SESSION['userid'];
	$sql="SELECT * FROM `user-shown-ads` WHERE `userid`='$userid' AND `date`='$str_date__'";
	$query=mysqli_query($conn,$sql);
	$count=mysqli_num_rows($query);
	$fetch_count=mysqli_fetch_assoc($query);
			$shown_ads=($count+1);
			$sql="SELECT * FROM `ads-fetch_300x250` WHERE `id`='$shown_ads'";
	        $query=mysqli_query($conn,$sql);
	        $count=mysqli_num_rows($query);
			$fetch=mysqli_fetch_assoc($query);
			$ads_id=$fetch['id'];
			echo($fetch['ads-fetch_300x250'].'<input type="text" value="'.$userid.'" id="userid" hidden="hidden"><br><input type="text" value="'.$ads_id.'" id="count" hidden="hidden"><br><input type="text" value="'.$str_date__.'" id="date" hidden="hidden">');
			
		}
	}
		else
		{
			$shown_ads=($count+1);
			$sql="SELECT * FROM `ads-fetch_300x250` WHERE `id`='$shown_ads'";
	        $query=mysqli_query($conn,$sql);
	        $count=mysqli_num_rows($query);
			$fetch=mysqli_fetch_assoc($query);
			$ads_id=$fetch['id'];
			echo($fetch['ads-fetch_300x250'].'<input type="text" value="'.$userid.'" id="userid" hidden="hidden"><br><input type="text" value="'.$ads_id.'" id="count" hidden="hidden"><br><input type="text" value="'.$str_date__.'" id="date" hidden="hidden">');
			
		}
	
}
else{
	echo("not working.");
}

?>