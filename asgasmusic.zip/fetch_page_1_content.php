<?php

		include"db.php";
		$sql_movie_name_fetch="SELECT * FROM `albumart_&_details` WHERE `type`='Bollywood' ORDER BY `id` DESC LIMIT 6";
		$query_movie_name_fetch=mysqli_query($conn,$sql_movie_name_fetch);
		while($fetch_movie_name=mysqli_fetch_assoc($query_movie_name_fetch))
		  {
			  echo '<a href="music show.php?moviename='.$fetch_movie_name['moviename'].'&type='.$fetch_movie_name['type'].'" style="text-decoration:none;"><div class="song"><!--Start of the song list div-->
	<div class="albumart"><!--Start of the albumart div-->
		<img src="'.$fetch_movie_name['address'].'" width="70" height="70" class="alubumart-image">
		<div class="glass-song-effect"><!--Start of the glass effect div-->
		   <div><!--Start of the movie song name glass effect div-->
			<marquee direction="left" scrolldelay="200"><p>'.$fetch_movie_name['moviename'].'</p></marquee>
			</div><!--End of the movie song name glass effect div-->
		</div><!--End of the glass effect div-->
	</div><!--End of the albumart div-->
	<div class="song-ditails"><!--Start of the song ditails div-->
		<div class="movie-name"><marquee direction="top" scrolldelay="150">'.$fetch_movie_name['moviename'].'</marquee></div>
		<div class="movie-or-album">'.$fetch_movie_name['movie/album'].'</div>
	</div><!--End of the song ditails div-->
	</div></a><!--End of the song list div-->';
	
		  }
		
		
		
	
?>
