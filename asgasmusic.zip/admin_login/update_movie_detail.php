<?php
if(isset($_POST['movie_story'])&&isset($_POST['star'])&&isset($_POST['producer'])&&isset($_POST['director'])&&isset($_POST['release_date'])&&isset($_POST['writer'])&&isset($_POST['music_director'])&&isset($_POST['movie_name'])&&isset($_POST['type']))
  {
	  include "../db.php";
	  $dates=date('d/m/y H:i:s a',time());
	  $id=uniqid();
	  $movie_story=$_POST['movie_story'];
	  $star=$_POST['star'];
	  $producer=$_POST['producer'];
	  $director=$_POST['director'];
	  $release_date=$_POST['release_date'];
	  $writer=$_POST['writer'];
	  $music_director=$_POST['music_director'];
	  $moviename=$_POST['movie_name'];
	  $type=$_POST['type'];
	  $sql="INSERT INTO `movie-ditails`(`id-random`, `movie-story`, `producer`, `star`, `director`, `music-director`, `releas-date`, `writer`, `movie-name`, `likes`, `date`, `type`) VALUES ('$id','$movie_story','$producer','$star','$director','$music_director','$release_date','$writer','$moviename','0','$dates','$type')";
	  if(mysqli_query($conn,$sql))
	     {
			 echo 000;
		 }
	  else
	     {
			 echo 101;
			 		 }
  }
  else
    {
		echo 404;
	}
?>