<?php
if(isset($_POST['phone'])&&isset($_POST['txnid']))
  {
	  echo $_POST['phone']."<br> "; 
	  echo $_POST['txnid'];
  }
  ?>