<?php
if(isset($_POST['mobile']))
   {
	   include"../db.php";
	   $num=$_POST['mobile'];
	   $_num=mysqli_real_escape_string($conn,$num);
	   
	   $sql="SELECT * FROM `adminlogindata` WHERE `phone`='$_num'";
	   if($query=mysqli_query($conn,$sql))
	       {
			   $result=mysqli_fetch_assoc($query);
			   if(mysqli_num_rows($query)>0)
			      {
					  $id=rand(0000,9999);
					   date_default_timezone_set("Asia/kolkata");
	                                   $timezone=date_default_timezone_get();
					   $time=date('d-m-Y h:i:s a', time());
					   $userid=$result['Randomid'];
					    $username=$result['Name'];
						 $user_token=$result['TokenNum'];
						 $sql_insert="INSERT INTO `otp_request`(`Randomid`, `Userid`, `UserName`, `Token`, `Time`) VALUES('$id','$userid','$username','$user_token','$time')";
						 if($query_otp=mysqli_query($conn,$sql_insert))
						       {
								   $msg="Your One Time PassWord Is. ".$id."-".$user_token." Please Provide Full Code 'example:-1005-4236'.";
								   include('way2sms-api.php');
                                   sendWay2SMS ( '7687944113' , '1995' , $num , $msg);
								   $token_update=rand(00000,99999);
								   $sql_update="UPDATE `adminlogindata` SET `TokenNum`='$token_update' WHERE `phone`='$_num'";
								   $query_update=mysqli_query($conn,$sql_update);
								   echo 000;
							   }
						else
						      {
								  echo 111;
							  }
				  }
				 else
				    {
						echo 9999;
					}
				  
		   }
   }
?>