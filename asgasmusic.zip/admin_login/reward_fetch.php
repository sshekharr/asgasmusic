
<html>
<head>
<title>Reward
</title>
<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../jquery-ui.min.css" rel="stylesheet" type="text/css">
<script src="../js/jquery-min.js"></script>
<script src="../jquery-ui.min.js"></script>
</head>
<body>
<center><div id="reward_money_data" style=" min-width:610px; width:100%; height:70%; padding-top:10px;"><?php

if(isset($_POST['data'])||isset($_POST['phone'])&&isset($_POST['txnid']))
  {
	   include"../db.php";
	 if(isset($_POST['data']))
	    {
		 /*showing the request to the user*/	
	  $sql="SELECT * FROM `money-request` WHERE `status`='pending'";
	  $query=mysqli_query($conn,$sql);
	  while($fetch=mysqli_fetch_assoc($query))
	     {
			 $userid=$fetch['user_id'];
			 $sql_number="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	         $query_number=mysqli_query($conn,$sql_number);
			 $fetch_number=mysqli_fetch_assoc($query_number);
			 
			 echo '<div id="reward"  style="width:90%; margin:5px; padding:5px; height:100px; border:1px solid #000; background:white; min-width:600px;">
<div id="num" style="width:45%; height:40px; float:left; font-family:playlist"><center><h2>'.$fetch_number['mobileNo'].'</h2></center></div>
<div id="amount" style="width:45%; height:40px; float:right; font-family:playlist"><center><h3>('.$fetch['amount'].')</h3></center></div>
<div id="txn_id" style="width:100%; height:25px; font-family:playlist; float:left; padding-top:7px;">txnId:-'.$fetch['txt_id'].'</div>
<div id="butn"><form action="reward_fetch.php" method="post">
<input type="text" value="'.$fetch_number['mobileNo'].'" style="display:none" name="phone">
<input type="text" value="'.$fetch['txt_id'].'" style="display:none" name="txnid"><button type="submit" id="update_reward" onClick="update_reward()" class="ui-button" phone="'.$fetch_number['mobileNo'].'" txnid="'.$fetch['txt_id'].'" style="font-family:playlist;">Complete</button></form></div>
</div>';
		 }
		  /*end of the showing the request to the user*/
		}
	else if(isset($_POST['phone'])&&isset($_POST['txnid']))
	   {
		   /*updating the user data from request money status*/
		   $txnid=$_POST['txnid'];
		   $phone=$_POST['txnid'];
		   $sql_update="UPDATE `money-request` SET `status`='complete' WHERE `txt_id`='$txnid'";
		   $query_update=mysqli_query($conn,$sql_update);
		   /*end of the updating the user data from request money status*/
		   /*fetching user data from request money*/
		   $sql_data="SELECT * FROM `money-request` WHERE `txt_id`='$txnid'";
		   $query_data=mysqli_query($conn,$sql_data);
		   $fetch_update=mysqli_fetch_assoc($query_data);
		   $user_id=$fetch_update['user_id'];
		   $name=$fetch_update['Name'];
		   $email=$fetch_update['Email'];
		   /* end of the fetching user data from request money*/
		   /*NOTIFICATION CODE start*/
		   $ran_id=uniqid();
	      $sql_notification="INSERT INTO `notification-user`(`randomId`, `user_id`, `Name`, `Email`, `status`, `subject`, `notification`) VALUES('$ran_id','$user_id','$name','$email','unread','Transaction Complete','YOUR REDEEMED AMOUNT IS SUCESSFULL TRANSFER IN YOUR REGISTERED PAYTM NUMBER.')";
		  $query_noti=mysqli_query($conn,$sql_notification);
		  /*NOTIFICATION CODE END*/
		  /*showing the request to the user*/
		  $sql="SELECT * FROM `money-request` WHERE `status`='pending'";
	      $query=mysqli_query($conn,$sql);
		  		  
	  while($fetch=mysqli_fetch_assoc($query))
	     {
			 
			 $userid=$fetch['user_id'];
			 $sql_number="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	         $query_number=mysqli_query($conn,$sql_number);
			 $fetch_number=mysqli_fetch_assoc($query_number);
			 
			 echo '<div id="reward"  style="width:90%; margin:5px; padding:5px; height:100px; border:1px solid #000; background:white; min-width:600px;">
<div id="num" style="width:45%; height:40px; float:left; font-family:playlist"><center><h2>'.$fetch_number['mobileNo'].'</h2></center></div>
<div id="amount" style="width:45%; height:40px; float:right; font-family:playlist"><center><h3>('.$fetch['amount'].')</h3></center></div>
<div id="txn_id" style="width:100%; height:25px; font-family:playlist; float:left; padding-top:7px;">txnId:-'.$fetch['txt_id'].'</div>
<div id="butn"><form action="reward_fetch.php" method="post">
<input type="text" value="'.$fetch_number['mobileNo'].'" style="display:none" name="phone">
<input type="text" value="'.$fetch['txt_id'].'" style="display:none" name="txnid"><button type="submit" id="update_reward" onClick="update_reward()" class="ui-button" phone="'.$fetch_number['mobileNo'].'" txnid="'.$fetch['txt_id'].'" style="font-family:playlist;">Complete</button></form></div>
</div>';
		 }
	 /*end of the showing the request to the user*/
	   }
  }
 
?></div></center>
</body>
</html>