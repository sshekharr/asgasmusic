$(document).ready(function(e) {
	var movie_story;
	var star;
	var producer;
	var director;
	var release_date;
	var writer;
	var music_director;
	var movie_name;
	var type;
	$("#type").change(function(e) {
		type=$("#type").val();
		if(type=='null')
			 {
				 toastr.error("Please Select The Correct Option");
			   $("#type").css("border","4px solid #e45641");
			   $.removeCookie('movie_name',{path:'/'});
			 }
		else
		   {
			   $("#type").css("border","none");
				$.cookie('type','ok');
		   }
	});
	$("#movie_name").focusout(function(e) {
       movie_name=$("#movie_name").val();
	   if($.trim(movie_name).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#movie_name").css("border","4px solid #e45641");
			   $.removeCookie('movie_name',{path:'/'});
		  }
		else if(movie_name=='undefined'|| movie_name=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#movie_name").css("border","4px solid #e45641");
			   $.removeCookie('movie_name',{path:'/'});
		  }
		else
		   {
			    $("#movie_name").css("border","none");
				$.cookie('movie_name','ok');
		   }
    });
	$("#movie_story").focusout(function(e) {
       movie_story=$("#movie_story").val();
	   if($.trim(movie_story).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#movie_story").css("border","4px solid #e45641");
			   $.removeCookie('movie_story',{path:'/'});
		  }
		else if(movie_story=='undefined'|| movie_story=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#movie_story").css("border","4px solid #e45641");
			   $.removeCookie('movie_story',{path:'/'});
		  }
		else
		   {
			    $("#movie_story").css("border","none");
				$.cookie('movie_story','ok');
		   }
    });
	$("#star").focusout(function(e) {
        star=$(this).val();
		if($.trim(star).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#star").css("border","2px solid #e45641");
			   $.removeCookie('star',{path:'/'});
		  }
		else if(star=='undefined'|| star=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#star").css("border","2px solid #e45641");
			   $.removeCookie('star',{path:'/'});
		  }
		else
		   {
			    $("#star").css("border","none");
				$.cookie('star','ok');
		   }
    });
	$("#director").focusout(function(e) {
        director=$(this).val();
		if($.trim(director).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#director").css("border","2px solid #e45641");
			   $.removeCookie('director',{path:'/'});
		  }
		else if(director=='undefined'|| director=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#director").css("border","2px solid #e45641");
			   $.removeCookie('director',{path:'/'});
		  }
		else
		   {
			    $("#director").css("border","none");
				$.cookie('director','ok');
		   }
    });
	$("#writer").focusout(function(e) {
        writer=$(this).val();
		if($.trim(writer).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#writer").css("border","2px solid #e45641");
			   $.removeCookie('writer',{path:'/'});
		  }
		else if(writer=='undefined'|| writer=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#writer").css("border","2px solid #e45641");
			   $.removeCookie('writer',{path:'/'});
		  }
		else
		   {
			    $("#writer").css("border","none");
				$.cookie('writer','ok');
		   }
    });
	$("#producer").focusout(function(e) {
        producer=$(this).val();
		if($.trim(producer).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#producer").css("border","2px solid #e45641");
			   $.removeCookie('producer',{path:'/'});
		  }
		else if(producer=='undefined'|| producer=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#producer").css("border","2px solid #e45641");
			   $.removeCookie('producer',{path:'/'});
		  }
		else
		   {
			    $("#producer").css("border","none");
				$.cookie('producer','ok');
		   }
    });
	$("#music_director").focusout(function(e) {
        music_director=$(this).val();
		if($.trim(music_director).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#music_director").css("border","2px solid #e45641");
			   $.removeCookie('music_director',{path:'/'});
		  }
		else if(music_director=='undefined'|| music_director=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#music_director").css("border","2px solid #e45641");
			   $.removeCookie('music_director',{path:'/'});
		  }
		else
		   {
			    $("#music_director").css("border","none");
				$.cookie('music_director','ok');
		   }
    });
	$("#release_date").focusout(function(e) {
        release_date=$(this).val();
		if($.trim(release_date).length==0)
	      {
			  toastr.error("Field Required Some Text");
			   $("#release_date").css("border","2px solid #e45641");
			   $.removeCookie('release_date',{path:'/'});
		  }
		else if(release_date=='undefined'|| release_date=="" )  
		  {
			  toastr.error("Field Required Some Text");
			   $("#release_date").css("border","2px solid #e45641");
			   $.removeCookie('release_date',{path:'/'});
		  }
		else
		   {
			    $("#release_date").css("border","none");
				$.cookie('release_date','ok');
		   }
    });
    $(".submit_btn").click(function(e) {
       var cmd=$.cookie('music_director');
	   var cdir=$.cookie('director');
	   var cstar=$.cookie('star');
	   var cmdet=$.cookie('movie_story');
	   var cpro=$.cookie('producer');
	   var credat=$.cookie('release_date');
	   var cwriter=$.cookie('writer');
		var cmovie_name=$.cookie('movie_name');
		var ctype=$.cookie('type');
	   if(cmd&&cdir&&cstar&&cmdet&&cpro&&credat&&cwriter&&cmovie_name&&ctype)
	      {
			 
			  $.ajax({
				      type:'POST',
					  url:"update_movie_detail.php",
					  data:{'movie_story':movie_story,'star':star,'producer':producer,'director':director,'release_date':release_date,'writer':writer,'music_director':music_director,'movie_name':movie_name,'type':type},
					  beforeSend: function(){
						   $(".loader").css("display","block");
						  },
					  success: function(msg)
					    {
						    if(msg==000)
							    {
									toastr.success("Data is successfully Uploaded");
									$.removeCookie('music_director',{path:'/'});
									$.removeCookie('director',{path:'/'});
									$.removeCookie('star',{path:'/'});
									$.removeCookie('movie_story',{path:'/'});
									$.removeCookie('producer',{path:'/'});
									$.removeCookie('release_date',{path:'/'});
									$.removeCookie('writer',{path:'/'});
									$(".loader").css("display","none");
								}
							if(msg==101)
							   {
								   toastr.error("Error in uploading data");
								    $.removeCookie('music_director',{path:'/'});
									$.removeCookie('director',{path:'/'});
									$.removeCookie('star',{path:'/'});
									$.removeCookie('movie_story',{path:'/'});
									$.removeCookie('producer',{path:'/'});
									$.removeCookie('release_date',{path:'/'});
									$.removeCookie('writer',{path:'/'});
									$(".loader").css("display","none");
								   
							   }
							  if(msg==404)
							    {
									toastr.error("Please fill the field Correctly");
									$.removeCookie('music_director',{path:'/'});
									$.removeCookie('director',{path:'/'});
									$.removeCookie('star',{path:'/'});
									$.removeCookie('movie_story',{path:'/'});
									$.removeCookie('producer',{path:'/'});
									$.removeCookie('release_date',{path:'/'});
									$.removeCookie('writer',{path:'/'});
									$(".loader").css("display","none");
								}
						}
				  });
		  }
		else
			{
				toastr.error("Please fill the field Correctly");
			}
    });
});