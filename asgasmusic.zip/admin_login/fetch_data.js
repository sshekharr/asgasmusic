// JavaScript Document
$(document).ready(function(e) {
	$("#go").click(function(e) {
        window.location.href="reward.php"
    });
	$("#go_complete").click(function(e) {
        window.location.href="rewarded.php"
    });
	$("#go_upload").click(function(e) {
        window.location.href="upload.php";
    });
	$("#go_albumart").click(function(e) {
        window.location.href="upload_album.php";
    });
    $.ajax({
		    type:'POST',url:"reward_fetch.php",
			data:{data:1},
			success: function(msg){
				$("#reward_money_data").html(msg);
				}
		});
	$("#btn_amount_update").click(function(e) {
        var amount=$("#update_amount").val();
		if(amount.length==0||amount.length==""||$.trim(amount).length==0)
		    {
				 toastr.error("Please Enter The Valid Amount.");
				 
			}
		 if($.isNumeric(amount))
		    {
				var update_amount=$("#update_amount").val();
				$.ajax({
					    type:'POST',url:"update_amount.php",
						data:{amount:update_amount},
						beforeSend: function(){
						
							 $("amount_update").attr("class","ui-state-disabled"); 
							  $("#field_set").attr("class","ui-state-disabled");
							},
						success: function(msg){
							   
								 $("amount_update").attr("class","none");
								  $("#field_set").attr("class","none");
								  if(msg==1)
								     {
										 toastr.success("Amount Sucessfully Updated!!");
									 }
								   else
								     {
										toastr.error("Unable To Update."); 
									 }
							}
					});
			}
    });	
		
});
