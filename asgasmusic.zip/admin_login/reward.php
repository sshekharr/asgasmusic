<?php
session_start();
if(!isset($_SESSION['AdminUserId']))
  {
	 header("location:index.php"); 
  }
?>
<html>
<head>
<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../jquery-ui.min.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reward</title>
</head>

<body>
<center><div id="reward_money_data" style=" min-width:610px; width:100%; height:70%; padding-top:10px;"></div></center>
</body>
<script src="../js/jquery-min.js"></script>
<script src="fetch_data.js"></script>
<script src="../jquery-ui.min.js"></script>
</html>