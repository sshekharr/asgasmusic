<?php
session_start();
if(!isset($_SESSION['AdminUserId']))
  {
	 header("location:index.php"); 
  }

if($_POST['moviename']!=""&&$_POST['songname']!=""&&$_POST['m/a']!=""&&$_POST['yearofrelease']!=""&&$_POST['singer']!=""&&$_POST['amount']!=""&&$_POST['type']!="null")
    {   
		$fetchName=$_FILES['song']['name'];
		$realname=explode('.',$_FILES['song']['name']);
		$ext_name=end($realname);
		if($ext_name=='mp3'||$ext_name=='MP3')
		   {
			   include"../db.php";
			   $rand_id=rand(0,99);
			   $movie_name=$_POST['moviename'];
			   $song_name=$_POST['songname'];
			   $movie_album=$_POST['m/a'];
			   $type=$_POST['type'];
			   if($movie_album=='a'|| $movie_album=='A')
			      {
					  $movie_album1='album';
				  }
				 if($movie_album=='m'|| $movie_album=='M')
			      {
					  $movie_album1='movie';
				  } 
			   $yearofrelease=$_POST['yearofrelease'];
			   $singer=$_POST['singer'];
			   $amount=$_POST['amount'];
			   $path="../songs/";
			   $song_id=uniqid();
			   $date=date('y-m-d h:i:s a',time());
			   $uploader_id=$_SESSION['AdminUserId'];
			   $address=$path.$song_name.$rand_id.'.'.$ext_name;
			   $address1="songs/".$song_name.$rand_id.'.'.$ext_name;
			   if(move_uploaded_file($_FILES['song']['tmp_name'],$address))
			      {
					  $sql_song_upload="INSERT INTO `music_name_&_details`(`SongName`, `address`, `Movie/Album`, `MovieName`, `YearOfRelease`, `Singer-s`, `MusicDirector`, `Duration`, `AlbumArt`, `Amount`, `UploadingData`, `UploaderId`, `RandomId`,`type`) VALUES ('$song_name','$address1','$movie_album1','$movie_name','$yearofrelease','$singer','-','-','-','$amount','$date','$uploader_id','$song_id','$type')";
					  $query_upload_song=mysqli_query($conn,$sql_song_upload);
					  echo"11";
				  }
				else
				  {
					  echo"100";
				  }
			   
			   
				 
			   
		   }
		 else
		 {
			 echo "103";
		 }
	}
else
{
	echo 000;
}

?>