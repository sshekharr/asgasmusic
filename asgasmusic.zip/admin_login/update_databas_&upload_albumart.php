<?php
session_start();
if(!isset($_SESSION['AdminUserId']))
  {
	 header("location:index.php"); 
  }

if($_POST['moviename']!=""&&$_POST['m/a']!=""&&$_POST['type']!="null")
    {
		$fetchName=$_FILES['albumart']['name'];
		$realname=explode('.',$_FILES['albumart']['name']);
		$ext_name=end($realname);
		if($ext_name=='BMP'||$ext_name=='bmp'||$ext_name=='GIF'||$ext_name=='gif'||$ext_name=='JPE'||$ext_name=='jpe'||$ext_name=='JPEG'||$ext_name=='jpeg'||$ext_name=='JPG'||$ext_name=='jpg'||$ext_name=='PNG'||$ext_name=='png')
		   {
			   include"../db.php";
			   $rand_id=rand(0,99);
			   $movie_name=$_POST['moviename'];
			   $movie_album=$_POST['m/a'];
			   $type=$_POST['type'];
			   if($movie_album=='a'|| $movie_album=='A')
			      {
					  $movie_album1='album';
				  }
				 if($movie_album=='m'|| $movie_album=='M')
			      {
					  $movie_album1='movie';
				  } 
				  
			   $path="../albumart/";
			   $albumart_id=uniqid();
			   $date=date('y-m-d h:i:s a',time());
			   $uploader_id=$_SESSION['AdminUserId'];
			   $albumart_name=explode('.',$fetchName);
			   $albumart_name1=$albumart_name[0];
			   $address=$path.$movie_name.$rand_id.'.'.$ext_name;
			   $address1="albumart/".$movie_name.$rand_id.'.'.$ext_name;
			   
			   if(move_uploaded_file($_FILES['albumart']['tmp_name'],$address))
			      {
					  $sql_albumart_upload="INSERT INTO `albumart_&_details`(`albumId`, `albumart`, `address`, `movie/album`, `moviename`, `uploadername`, `date`,`type`) VALUES ('$albumart_id','$albumart_name1','$address1','$movie_album1','$movie_name','$uploader_id','$date','$type')";
					  $query_upload_albumart=mysqli_query($conn,$sql_albumart_upload);
					  $sql_subscriber="SELECT * FROM `subcriber`";
					  $_query=mysqli_query($conn,$sql_subscriber);
					  while($fetch_subscriber=mysqli_fetch_assoc($_query))
					     {
							 $email=$fetch_subscriber['email'];
require("class.phpmailer.php");

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "bh-ht-3.webhostbox.net";

$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Port = 465;
$mail->Username = "noreply@asgasmusic.com";
$mail->Password = "asgasmusic@2016";

$mail->From = "noreply@asgasmusic.com";
$mail->FromName = "Asgasmusic";
$mail->AddAddress($email);

$mail->IsHTML(true);


$mail->Subject = "AsgasMusic email Notification.";
$mail->Body = "<h1>HUURY!! HURRY!! HURRY!!.New Music Has Been Released .</h1><br><center><br><strong>Movie Name:- $movie_name</strong><br><a href='www.asgasmusic.com/music show.php?moviename=$movie_name&type=$type'><br><button style='-moz-box-shadow: 0px 10px 14px -7px #276873;
	-webkit-box-shadow: 0px 10px 14px -7px #276873;
	box-shadow: 0px 10px 14px -7px #276873;
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #599bb3), color-stop(1, #408c99));
	background:-moz-linear-gradient(top, #599bb3 5%, #408c99 100%);
	background:-webkit-linear-gradient(top, #599bb3 5%, #408c99 100%);
	background:-o-linear-gradient(top, #599bb3 5%, #408c99 100%);
	background:-ms-linear-gradient(top, #599bb3 5%, #408c99 100%);
	background:linear-gradient(to bottom, #599bb3 5%, #408c99 100%);
	background-color:#599bb3;
	-moz-border-radius:8px;
	-webkit-border-radius:8px;
	border-radius:8px;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:20px;
	font-weight:bold;
	padding:13px 32px;
	text-decoration:none;
	text-shadow:0px 1px 0px #3d768a; cursor:pointer;'>DOWNLOAD NOW!!</button></center>";






						 }
					  echo"10";
				  }
				else
				  {
					  echo"100";
				  }
			   
			   
				 
			   
		   }
		 else
		 {
			 echo "103";
		 }
	}
else
{
	echo 000;
}

?>