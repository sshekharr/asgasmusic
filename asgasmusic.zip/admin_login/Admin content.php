<?php
session_start();
include"../db.php";
if(!isset($_SESSION['AdminUserId']))
  {
	 header("location:index.php"); 
  }
?>
<html>
<head>
<title>Asgas Admin
</title>
<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="../css/toastr.css" rel="stylesheet" type="text/css">
</head>
<body style="padding-bottom:20px; min-width:800px;">
<div class="logout" style="width:70px; height:70px; margin-top:8px; margin:5px;"><a href="../logout.php" style="float:right;"><img src="../all_icons/logout-min.png" width="70" height="70" style=" padding-left:95%;float:right;"></a></div>
<div id="amount_update" class="">
<fieldset style="width:94%; border-radius:10px;" class="" id="field_set">
<legend><h1 style="font-family:playlist"><center>SONG RATE</center></h1></legend>
<div id="current_amount_rate" style="width:45%; float:left; padding-left:15px; height:90px; padding-top:30px; font-size:18px; font-family:playlist; padding-bottom:20px;"><center><h1>CURRENT AMOUNT RATE:-'<?php
 $sql_get_amount="SELECT * FROM `music_name_&_details`";
 $query_get_amount=mysqli_query($conn,$sql_get_amount);
 $fetch_get_amount=mysqli_fetch_assoc($query_get_amount);
  echo $fetch_get_amount['Amount'];        
?>'<h1></center></div>
<div id="current_amount_rate" style="width:45%; float:right;padding-left:15px; height:90px;padding-top:50px;"><input type="text" id="update_amount" placeholder="ENTER THE NEW AMOUNT"  style="width:300px; height:35px; text-align:center; margin:10px;"><img src="../all_icons/giphy.gif" width="70" height="70"  id="loading"style="display:none; margin:0px;"><button id="btn_amount_update" class="ui-button" style="width:100px; height:35px;">UPDATE!!</button></div>
</fieldset>
</div>
<div class="movie_details">
<div class="loader"></div>
<center>-:MOVIE DETAILS:-</center>
<textarea id="movie_story" class="movie_story"></textarea>
<input type="text" id="star" class="text_box" placeholder="Starring">
<input type="text" id="director" class="text_box" placeholder="Director">
<input type="text" id="writer" class="text_box" placeholder="Writers">
<input type="text" id="producer" class="text_box" placeholder="Production company">
<input type="text" id="music_director" class="text_box" placeholder="Music director">
<input type="text" id="release_date" class="text_box" placeholder="Release date">
<input type="text" id="movie_name" class="text_box" placeholder="Movie Name">
<select id="type" class="text_box">
	<option value="null" selected >Select</option>
	<option value="Bollywood">Bollywood</option>
	<option value="Tollywood">Tollywood</option>
</select>
<br>
<br>
<br>
<br>
<center><button type="button" class="submit_btn">Submit</button></center>
</div>
<div id="acc_count">
<div id="id" class="txt"><center>-:NUMBER OF MEMBER:-</center></div>
<center>
<?Php
$sql="SELECT * FROM `login-&-signup-data`";
$QUERY=mysqli_query($conn,$sql);
$count=mysqli_num_rows($QUERY);
echo '<div id="count" style="font-size:90px; font-weight:bolder; font-family:playlist; overflow:auto;  padding-top:60px;">'.$count.'</div><br>';
?></center>
</div>
<div id="page_view_2day" style=""><div id="id" class="txt"><center>-:TODAY TOTAL PAGE VIEWED:-</center></div>
<center>
<?Php
$date_day=date('y-m-d');
$date=strtotime($date_day);
$sql_count="SELECT * FROM `pagecount` WHERE `date`='$date'";
$query1=mysqli_query($conn,$sql_count);
$fetch_count=mysqli_fetch_assoc($query1);
echo '<div id="count" style="font-size:90px; font-weight:bolder; font-family:playlist; overflow:auto;  padding-top:60px;">'.$fetch_count['view'].'</div><br>';
?></center>
</div>
<div id="reward_money">
<div id="id" class="txt"><center>-:REWARD:-</center></div>
<center>
<h1 id="go" style="font-size:75px; font-family:playlist; cursor:pointer;">
Click Here To GO!
</h1>
</center>
</div>
<div id="completed_id">
<div class="txt"><center>-:REWARDED USER:-</center></div>
<center>
<h1 id="go_complete" style="font-size:75px; font-family:playlist; cursor:pointer;">
Click Here To GO!
</h1>
</center>
</div><br>
<div id="song_upload">
<div id="upload" class="txt"><center>-:UPLOAD SONG:-</center></div>
<center><h1 id="go_upload" style="font-size:75px; font-family:playlist; cursor:pointer;">
Click Here To GO!
</h1></center>
</div>
<div id="album_art_upload">
<div class="txt"><center>-:UPLOAD ALBUMART:-</center></div>
<center>
<h1 id="go_albumart" style="font-size:75px; font-family:playlist; cursor:pointer;">
Click Here To GO!
</h1>
</center>
</div>
</body>
<script src="../js/jquery-min.js"></script>
<script src="../js/toastr.js"></script>
<script src="../js/jquery.cookie.js"></script>
<script src="fetch_data.js"></script>
<script src="movie_detail.js"></script>
<script src="../jquery-ui.min.js"></script>
</html>