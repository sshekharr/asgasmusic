<?php
session_start();
if(!isset($_SESSION['AdminUserId']))
  {
	 header("location:index.php"); 
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

	<link rel="stylesheet" href="bootstrap.css">
    
	<script src="jquery.js"></script>
    <script src="upload_album_art.js"></script>
	<style>
	@font-face {
    font-family:playlist;
    src:url(../all_icons/font/Comfortaa-Bold.ttf);
}
::-webkit-scrollbar{ width:8px; background:#F5F5F5;}
::-webkit-scrollbar-thumb{background-color: #F90;	
	background-image: -webkit-linear-gradient(45deg,
	                                          rgba(255, 255, 255, .2) 25%,
											  transparent 25%,
											  transparent 50%,
											  rgba(255, 255, 255, .2) 50%,
											  rgba(255, 255, 255, .2) 75%,
											  transparent 75%,
											  transparent)
}
::-webkit-scrollbar-track{
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	background-color: #F5F5F5;}
	#songs:hover{
		-webkit-box-shadow:  0px 4px 47px -6px rgba(0,0,0,0.75);
-moz-box-shadow:  0px 4px 47px -6px rgba(0,0,0,0.75);
box-shadow:  0px 4px 47px -6px rgba(0,0,0,0.75);
		}
	</style>
    <link rel="stylesheet" href="../css/toastr.css" type="text/css">
</head>
<body onLoad="music_upload();">
	<div class="container">

		<center><h1 style="font-family:playlist">AlbumArt Uploader</h1>

		<input type="file" name="images[]" id="images" multiple class="btn btn-success">
        <br>
        <div  id="progress"></div>
        <br>
        <div id="error" style="display:none;width:100%; height:35px; border:1px solid #d65c4a; border-radius:5px; background: url(../all_icons/Untitled-2-min.png)#e45641 no-repeat; text-align:center; font-family:playlist; font-weight:bolder; line-height:35px;">SOMETHING WENT WRONG!!</div>
        <div id="done" style=" display:none;width:100%; height:35px; border:1px solid #4cae4c; border-radius:5px; background: url(../all_icons/Untitled-2_ok-min.png)#5cb85c no-repeat; text-align:center; font-family:playlist; font-weight:bolder; line-height:35px;">ALBUMART SUCCESSFULLY UPLOADED!!</div>
        </center>
		<hr>
		<div id="album-to-upload">

		</div><!-- end #images-to-upload -->


	</div><!-- end .container -->
    <script src="../js/toastr.js"></script>
</body>
</html>