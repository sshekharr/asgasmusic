<?php
session_start();
if(!isset($_SESSION['AdminUserId']))
  {
	 header("location:index.php"); 
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

	<link rel="stylesheet" href="bootstrap.css">
    <link href="../jquery-ui.min.css" rel="stylesheet" type="text/css">
    <link href="../css/toastr.css" rel="stylesheet" type="text/css">
	<script src="jquery.js"></script>
    <script src="../jquery-ui.min.js"></script>
    <script src="upload_music.js"></script>
    <script src="../js/toastr.js"></script>
    <script src="../js/jquery.cookie.js"></script>
	<style>
	@font-face {
    font-family:playlist;
    src:url(../all_icons/font/Comfortaa-Bold.ttf);
}
::-webkit-scrollbar{ width:8px; background:#F5F5F5;}
::-webkit-scrollbar-thumb{background-color: #F90;	
	background-image: -webkit-linear-gradient(45deg,
	                                          rgba(255, 255, 255, .2) 25%,
											  transparent 25%,
											  transparent 50%,
											  rgba(255, 255, 255, .2) 50%,
											  rgba(255, 255, 255, .2) 75%,
											  transparent 75%,
											  transparent)
}
::-webkit-scrollbar-track{
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	background-color: #F5F5F5;}
	#songs:hover{
		-webkit-box-shadow:  0px 4px 47px -6px rgba(0,0,0,0.75);
-moz-box-shadow:  0px 4px 47px -6px rgba(0,0,0,0.75);
box-shadow:  0px 4px 47px -6px rgba(0,0,0,0.75);
		}
	</style>
	
</head>
<body onLoad="music_upload();">
	<div class="container">
   
      <div id="movie_name_update" style="margin:15px;" class="">
      <h2>PLEASE PROVIDE THE SAME NAME IN MOVIE NAME UPDATE AND SONG UPLOADER. </h2>
      <fieldset style="width:100%; border-radius:10px;" class="" id="field_set_movie">
<legend><h1 style="font-family:playlist"><center>MOVIE NAME UPDATE</center></h1></legend>
       <center>
       <label for="movie_update">Movie/SingleSong Name:</label>
       <input type="text" status="notdone" placeholder="ENTER THE MOVIE NAME" style="text-align:center; width:14em; height:40px; padding-left:10px; text-align:center; font-size:14px;" id="movie_update" class="form-control"><br>
       <label for="m_a">Select Movie/Album</label><br>
       <select id="m_a" status="undone" class="selectpicker abc" style="width:250px;">
       <option value="null" selected>Select</option>
       <option value="movie">movie</option>
       <option value="album">album</option>
        </select><br>
       <label for="h_b">HOLLYWOOD/BOLLYWOOD</label><br>
       <select id="h_b" status="undone" class="selectpicker abc" style="width:250px;">
       <option value="null" selected>Select</option>
       <option value="Bollywood">Bollywood</option>
       <option value="Hollywood">Hollywood</option>
       <option value="Best Of Me">Best Of Me</option>
       <option value="Tollywood">Tollywood</option>
        </select><br><br>
        
        <button id="movie_name_updated" class="ui-button" style="width:100px; height:35px;">UPDATE!!</button>
       </center></fieldset></div><!-- end #movie_name_update -->
       <div id="uploader" class=" ui-state-disabled" status="notdone">
		<center><h1 style="font-family:playlist">Song Uploader</h1>

		<input type="file" name="images[]" id="images" multiple class="btn btn-success">
        <br>
        <div  id="progress"></div>
        <br>
        <div id="error" style="display:none;width:100%; height:35px; border:1px solid #d65c4a; border-radius:5px; background: url(../all_icons/Untitled-2-min.png)#e45641 no-repeat; text-align:center; font-family:playlist; font-weight:bolder; line-height:35px;">SOMETHING IS MISSING IN THE SONG INFORMATION.PLEALE CORRECT IT AND HIT UPLOAD BUTTON!!</div>
        <div id="done" style=" display:none;width:100%; height:35px; border:1px solid #4cae4c; border-radius:5px; background: url(../all_icons/Untitled-2_ok-min.png)#5cb85c no-repeat; text-align:center; font-family:playlist; font-weight:bolder; line-height:35px;">SONG SUCCESSFULLY UPLOADED!!</div>
        </center>
		<hr>
		<div id="song-to-upload">

		</div><!-- end #images-to-upload -->
        </div><!-- end #uploader -->
        
 <center><a href="upload_album.php"><button >GO TO ALBUM UPLOADER</button></a></center>

	</div><!-- end .container -->
</body>
</html>