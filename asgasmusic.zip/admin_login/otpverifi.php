<?php
sleep(2);
session_start();
if(isset($_POST['otp']))
   { 
       include "../db.php";
	   $otp=$_POST['otp'];
	   $_otp=explode("-",$otp);
	   $usertoken=$_otp[1];
	   $id=$_otp[0];
	   
	   $sql="SELECT * FROM `otp_request` WHERE `Randomid`='$id' AND `Token`='$usertoken'";
	   $query=mysqli_query($conn,$sql);
	   if(mysqli_num_rows($query))
	       {
			   $fetch=mysqli_fetch_assoc($query);
			   $_SESSION['AdminUserId']=$fetch['Userid'];
			   $sql_delet="DELETE FROM `otp_request` WHERE `Randomid`='$id' AND `Token`='$usertoken'";
			   $query_delet=mysqli_query($conn,$sql_delet);
			   echo 000;		  
			   
		  }
		else
		   {
			   echo 111;
		   }
		   
   }
  else
     {
		 echo 222;
	 }
?>