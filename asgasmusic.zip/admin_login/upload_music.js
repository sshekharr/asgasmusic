// JavaScript Document
$(document).ready(function(e) {
	setInterval(function(){
		       var movie_name=$("#movie_update").attr("status");
			   var m_a=$("#m_a").attr("status");
			   var uploader=$("#uploader").attr("status");
			   
			   if(movie_name=='done'&&m_a=='done')
			         {
						 $("#uploader").attr("class","none");
					 }
				if(uploader=='done')
				    {
						$("#albumart_update").attr("class","none");
					}
			   },500);
    $("#m_a").selectmenu();
	$("#h_b").selectmenu();
	var movie_update=$("#movie_update").val();
	$("#movie_update").focusout(function(e) {
        var movie_update=$(this).val();
		if(movie_update==""||movie_update.length==0||$.trim(movie_update).length==0)
		    {
				toastr.error("FIELD REQUIRED.");
			}
		else
		    {
				toastr.success("ALL GOOD!!");
				$.cookie("movie_update",movie_update,{path:"/"});
			}
			});
	$("#movie_name_updated").click(function(e) {
        var m_a=$("#m_a").val();
		var h_b=$("#h_b").val();
		if(m_a=='null'&&h_b=='null')
		  {
			  toastr.error("SELECT MENU FIELD REQUIRED.");
		  }
		else if(m_a=='null')
		  {
			  toastr.error("SELECT MENU FIELD REQUIRED.");
		  } 
		 else if(h_b=='null')
		  {
			  toastr.error("SELECT MENU FIELD REQUIRED.");
		  } 
		else  
		  {
			toastr.success("ALL GOOD!!");
				$.cookie("m_a",m_a,{path:"/"});  
				$.cookie("h_b",h_b,{path:"/"});
		  }
	  var movie_song=$.cookie("movie_update");
	  var m_a=$.cookie("m_a");
	  if(movie_song&&m_a&&h_b)
	      {
			  $.ajax({
				      type:'POST',url:"show_movie_name_update.php",
					  data:{movie_song:movie_song,m_a:m_a,h_b:h_b},
					  beforeSend: function(){
						      $("#movie_name_update").attr("class","ui-state-disabled");
						  },
					  success: function(msg){
						       if(msg==111) 
							       {
									   $.removeCookie("movie_update",{path:'/'});
									   $.removeCookie("m_a",{path:'/'});
									   toastr.success("MOVIE/SONG NAME SUCESSFULLY UPDATED!!");
									   $("#m_a").attr("status","done");
									   $("#movie_update").attr("status","done");
								   }
								 else {
									 $.removeCookie("movie_update",{path:'/'});
									   $.removeCookie("m_a",{path:'/'});
									   toastr.error("ERROR UPDATED!!");
								 }
						  }
				  });
		  }
    });		

	
});
function music_upload(){
var fileCollection = new Array();

		$('#images').on('change',function(e){

			var files = e.target.files;
			var count=0;

			$.each(files, function(i, file){

				fileCollection.push(file);
				var name=fileCollection[count++]['name'];
				console.log(fileCollection);
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function(e){
                
					var template = '<form action="/upload"><div id="songs" style="width:900px; height:230px; border:1px solid #333; border-radius:8px;margin:15px auto;"><div id="music_icon" style="width:130px; height:160px; float:left; margin:3px; line-height:200px;"><img src="../all_icons/Music-icon-min.png" width="130" height="160" style="padding:5px;"></div><center><div id="preview" style="margin-top:8px; float:left; margin-left:100px;"><audio controls ><source src="'+e.target.result+'" type="audio/mpeg">Your browser does not support the audio element.</audio></div></center><br><div id="information" style="width:60%; float:left; height:105px; margin:3px; margin-top:4px; padding-left:50px;"><input type="text" name="moviename" id="moviename" placeholder="MovieName" style="float:left; margin:5px;" ><input type="text" name="songname" id="songname" placeholder="SongName" style="float:left; margin:5px;" ><br /><input type="text" name="m/a" id="m_a" placeholder="movie/album(m/a)" style="float:left; margin:5px;" ><input type="text" name="yearofrelease" id="yearofrelease" placeholder="year of release" style="float:left; margin:5px;" ><br /><input type="text" name="singer" id="singer" placeholder="Singer" style="float:left; margin:5px;" ><input type="text" name="amount" id="amount" placeholder="Amount" style="float:left; margin:5px;" ><br><select id="h_b" status="undone" class="selectpicker abc" style="width:300px; height:25px; margin-left:25px;" name="type"><option value="null" selected>Select</option><option value="Bollywood">Bollywood</option><option value="Hollywood">Hollywood</option><option value="Best Of Me">Best Of Me</option><option value="Tollywood">Tollywood</option></select></div><div id="upload" style="float:right; margin-top:35px; margin-right:20px; padding-right:60px; width:80px;"><button type="submit" id="upload_btn" class="btn btn-success">Upload</button></div><br><div id="name" style="font-size:18px; float:left; margin-top:30px; margin-left:6%;"><strong>'+name+'</strong></div></div></form>';

					$('#song-to-upload').append(template);
				};

			});

		});

		//form upload ... delegation
		$(document).on('submit','form',function(e){

			e.preventDefault();
			//this form index
			var index = $(this).index();

			var formdata = new FormData($(this)[0]); //direct form not object
               
			//append the file relation to index
			formdata.append('song',fileCollection[index]);
                  console.log(formdata);
				  $.ajax({
					     type:'POST',url:"update_databas_&upload_music.php",
						  data:formdata,
						  cache: false,
					contentType: false,
					processData: false,
					beforeSend: function(){
						$("#progress").empty();
						$("#error").css("display","none");
						$("#progress").html('<center><img src="../all_icons/cloud_upload_256.gif" width="128" height="128"></center>');
						},
						 success: function(msg){
							    if(msg==000)
								   {
									   $("#progress").html('<center><img src="../all_icons/cloud_upload_wrong_256-min.png" width="128" height="128"></center>');
									   toastr.error("SOMETHING IS MISSING IN THE SONG INFORMATION.PLEALE CORRECT IT AND HIT UPLOAD BUTTON!!");
									   $("#error").css("display","block");
								   }
								 if(msg==11)
								    {
										$("#progress").html('<center><img src="../all_icons/cloud_upload_256-min.png" width="128" height="128"></center>');
									   $("#done").css("display","block");
									   $("#uploader").attr("class","done");
									   toastr.success("MUSIC FILE SUCCESSFULLY UPLOADED!!");
									   $("#uploader").attr("class","ui-state-disabled");
									}
								 if(msg==103)
								    {
										$("#error").empty();
										$("#error").html('PLEASE UPLOAD CORRECT MUSIC FILE!!');
										$("#progress").html('<center><img src="../all_icons/cloud_upload_wrong_256-min.png" width="128" height="128"></center>');
										toastr.error("PLEASE UPLOAD CORRECT MUSIC FILE!!");
									   $("#error").css("display","block");
									}
								 if(msg==100)
								    {
										$("#error").empty();
										$("#error").html('UNABLE TO UPLOAD PLEASE REFRESH THE PAGE AND TRY AGAIN!!');
										$("#progress").html('<center><img src="../all_icons/cloud_upload_wrong_256-min.png" width="128" height="128"></center>');
										toastr.error("UNABLE TO UPLOAD PLEASE REFRESH THE PAGE AND TRY AGAIN!!");
									    $("#error").css("display","block");
									}
							     
							  }
					  });
			

		});
}