// JavaScript Document
function music_upload(){
var fileCollection = new Array();

		$('#images').on('change',function(e){

			var files = e.target.files;
			var count=0;

			$.each(files, function(i, file){

				fileCollection.push(file);
				var name=fileCollection[count++]['name'];
				console.log(fileCollection);
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function(e){
                
					var template = '<form action="/upload"><div id="songs" style="width:900px; height:300px; border:1px solid #333; border-radius:8px;margin:15px auto;"><div id="music_icon" style="width:250px; height:230px; float:left; margin:3px; line-height:200px;"><img src="'+e.target.result+'" width="250" height="230" style="padding:5px;"></div><div id="name" style="font-size:18px; float:left; margin-top:5px; margin-left:6%;"><strong>'+name+'</strong></div><br><div id="information" style="width:60%; float:left; height:105px; margin:3px; margin-top:4px; padding-left:50px;"><input type="text" name="moviename" id="moviename" class="form-control input-lg" placeholder="MovieName" style="float:left; margin:5px; margin-left:-15px" ><br /><input type="text" name="m/a" id="m_a" placeholder="movie/album(m/a)" style="float:left; margin:5px; margin-left:-15px;" class="form-control input-lg" ><br><center><select id="h_b" status="undone" class="selectpicker abc" style="width:300px; height:35px;" name="type"><option value="null" selected>Select</option><option value="Bollywood">Bollywood</option><option value="Hollywood">Hollywood</option><option value="Best Of Me">Best Of Me</option><option value="Tollywood">Tollywood</option></select></center><center><div id="upload" style="float:right; margin-top:35px; margin-right:20px; padding-right:60px; width:80px;"><button type="submit" id="upload_btn" class="btn btn-success">Upload</button></div><br></div></center></form>';

					$('#album-to-upload').append(template);
				};

			});

		});

		//form upload ... delegation
		$(document).on('submit','form',function(e){

			e.preventDefault();
			//this form index
			var index = $(this).index();

			var formdata = new FormData($(this)[0]); //direct form not object
               
			//append the file relation to index
			formdata.append('albumart',fileCollection[index]);
                  console.log(formdata);
				  $.ajax({
					     type:'POST',url:"update_databas_&upload_albumart.php",
						  data:formdata,
						  cache: false,
					contentType: false,
					processData: false,
					beforeSend: function(){
						$("#progress").empty();
						$("#error").css("display","none");
						$("#progress").html('<center><img src="../all_icons/cloud_upload_256.gif" width="128" height="128"></center>');
						},
						 success: function(msg){
							    if(msg==000)
								   {
									   $("#progress").html('<center><img src="../all_icons/cloud_upload_wrong_256-min.png" width="128" height="128"></center>');
									   toastr.error("SOMETHING WENT WRONG!!");
									   $("#error").css("display","block");
								   }
								 if(msg==10)
								    {
										$("#progress").html('<center><img src="../all_icons/cloud_upload_256-min.png" width="128" height="128"></center>');
									   $("#done").css("display","block");
									   toastr.success("ALBUMART SUCCESSFULLY UPLOADED!!");
									   
									}
								 if(msg==103)
								    {
										$("#error").empty();
										$("#error").html('PLEASE UPLOAD CORRECT ALBUMART FILE!!');
										$("#progress").html('<center><img src="../all_icons/cloud_upload_wrong_256-min.png" width="128" height="128"></center>');
										toastr.error("PLEASE UPLOAD CORRECT ALBUMART FILE!!");
									   $("#error").css("display","block");
									}
								 if(msg==100)
								    {
										$("#error").empty();
										$("#error").html('UNABLE TO UPLOAD PLEASE REFRESH THE PAGE AND TRY AGAIN!!');
										$("#progress").html('<center><img src="../all_icons/cloud_upload_wrong_256-min.png" width="128" height="128"></center>');      
										 toastr.error("UNABLE TO UPLOAD PLEASE REFRESH THE PAGE AND TRY AGAIN!!");
									    $("#error").css("display","block");
									}
							     
							  }
					  });
			

		});
}