$(document).ready(function(e) {
    $("#elogmob").click(function() {
        $("#moblogin").css("display","none");
		$("#emaillogin").css("display","block");
    });
	$("#elogemail").click(function() {
        $("#moblogin").css("display","block");
		$("#emaillogin").css("display","none");
    });
 $("#telnum").focusout(function(e) {
     var mobnumber=$("#telnum").val();
     if($.isNumeric(mobnumber))
	    {
			$.cookie("mobile",mobnumber,{path:"/"});
			
		}
		else
		{
			toastr.error("Please Enter Your Registered Mobile Number.");
		}
});

$("#numlogin").click(function() {
    var number=$.cookie("mobile");
	if(number)
	    {
			$.ajax({
				type:'POST',
				url:"admin verification.php",
				data:{mobile:number,},
				beforeSend: function(){$("#loading").css("display","block");},
				 success: function(msg){
					 $("#loading").css("display","none");
					 if(msg==000)
					     {
							 $.removeCookie("mobile",{path:'/'});
							 window.location.href="otp verification.php";
						 }
					   if(msg==111)
					     {
							toastr.error("Please Enter Your Registered Mobile Number. Window is refreshing in 2 sec."); 
							setInterval(function(){window.location.href="index.php";}, 3000);
						 }
						if(msg==9999)
						   {
							   console.log(msg);
							   $.removeCookie("mobile",{path:'/'});
						   }
					 }
			    
		});
		}
});
$("#otp").keyup(function(e) {
    var otp=$(this).val();
	if(otp==""|| otp.length<=0)
	    {
			toastr.error("Please Enter Valid OTP.");
		}
	else
	    {
			$.cookie("otp",otp,{path:'/'});
		}
});
$("#otp").focusout(function(e) {
    var otp=$(this).val();
	if(otp==""|| otp.length<=0)
	    {
			toastr.error("Please Enter Valid OTP.");
		}
		else
	    {
			$.cookie("otp",otp,{path:'/'});
		}
});

  $("#otpcheck").click(function(e) {
	  var otp1=$.cookie("otp");
    if(otp1)
	    {
			$.ajax({
				    type:'POST',
					data:{otp:otp1,},
					url:"otpverifi.php",
					beforeSend: function(){$("#loading").css("display","block");},
					success: function(msg){
						$("#loading").css("display","none");
						if(msg==000)
						    {
								window.location.href="Admin content.php";
								$.removeCookie("otp",{path:'/'})
							}
						else if(msg==111)
						    {
								toastr.error("Please Enter Valid OTP.");
								$.removeCookie("otp",{path:'/'})
							}
						else if(msg==222)
						    {
								toastr.error("Please Enter The OTP.");
								$.removeCookie("otp",{path:'/'})
							}
						}
				
				})
		}
	else
	    {
			toastr.error("Please Enter Valid OTP.");
		}
});
});