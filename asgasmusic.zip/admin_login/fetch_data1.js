// JavaScript Document
$(document).ready(function(e) {
	$("#go").click(function(e) {
        window.location.href="reward.php"
    });
   
		
});
function update_reward(){
	
	
	$("#reward_money_data").empty();
     
}