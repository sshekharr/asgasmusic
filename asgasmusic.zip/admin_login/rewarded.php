<?php
include"../db.php";
      /*showing the complete request money to the user*/
 $sql="SELECT * FROM `money-request` WHERE `status`='complete'";
	  $query=mysqli_query($conn,$sql);
	  while($fetch=mysqli_fetch_assoc($query))
	     {
			 $userid=$fetch['user_id'];
			 $sql_number="SELECT * FROM `login-&-signup-data` WHERE `randomId`='$userid'";
	         $query_number=mysqli_query($conn,$sql_number);
			 $fetch_number=mysqli_fetch_assoc($query_number);
			 
			 echo '<center><div id="reward"  style="width:90%; margin:5px; padding:5px; height:100px; border:1px solid #000; background:white; min-width:600px;">
<div id="num" style="width:45%; height:40px; float:left; font-family:playlist"><center><h2>'.$fetch_number['mobileNo'].'</h2></center></div>
<div id="amount" style="width:45%; height:40px; float:right; font-family:playlist"><center><h3>('.$fetch['amount'].')</h3></center></div>
<div id="txn_id" style="width:100%; height:25px; font-family:playlist; float:left; padding-top:7px;">txnId:-'.$fetch['txt_id'].'</div>
</div><center>';
		 }
		 /*end of the showing the complete request money to the user*/
?>
<html>
<head>
<title>Reward
</title>
<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../jquery-ui.min.css" rel="stylesheet" type="text/css">
<script src="../js/jquery-min.js"></script>
<script src="../jquery-ui.min.js"></script>
</head>
<body>
</body>