<?php
if(isset($_POST['amount']))
{
include"../db.php";
$amount=$_POST['amount'];
$sql_get_amount="UPDATE `music_name_&_details` SET `Amount`='$amount'";
if($query_get_amount=mysqli_query($conn,$sql_get_amount))
     {
		 echo 1;
	 }
else
     {
		 echo 0;
	 }
}
?>