<?php
session_start();
if(isset($_POST['movie_song'])&&isset($_POST['m_a'])&&isset($_POST['h_b']))
   { 
        include"../db.php";
	   $movie_song=$_POST['movie_song'];
	   $movie_album=$_POST['m_a'];
	   $type=$_POST['h_b'];
	   $date=date('d-m-y h:i:s a',time());
	   $uploaderId=$_SESSION['AdminUserId'];
	   $id=uniqid();
	   $sql="INSERT INTO `movie_song_name_fetch`(`Randomid`, `movie_song`, `movie_album`, `uploaderId`, `date`,`type`) VALUES ('$id','$movie_song','$movie_album','$uploaderId','$date','$type')";
	   if($query=mysqli_query($conn,$sql))
	       {
			   echo 111;
		   }
   }
?>