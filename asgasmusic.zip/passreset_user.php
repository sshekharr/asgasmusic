<?php
if($_GET['token']!=""&&$_GET['email']!="")
  {
	  include "db.php";
	  $tokenkey=$_GET['token'];
	  $email=$_GET['email'];
	  
	       $sql="SELECT * FROM `token-request` WHERE `tokenid`='$tokenkey'";
		   $query=mysqli_query($conn,$sql);
		   $count=mysqli_num_rows($query);
		   $fetch=mysqli_fetch_assoc($query);
		   $userid_update=$fetch['userid'];
		$uniid=$fetch['user-uniId'];
		   if($count>0)
		      {
				echo '<form action="set.php" method="get"><center><div id="finalpassreset" style=" min-width:600; min-height:300px;" >
<br><input type="password" style="width:300px; height:50px; padding:5px; line-height:50px;" class="form-control" id="newpass" placeholder="Enter The New Password" name="pass"><input type="password" style="display:none;width:300px; height:50px; padding:5px; line-height:50px;" class="form-control" id="newpass" placeholder="Enter The New Password" name="email" value="'.$email.'"><input type="password" style="display:none;width:300px; height:50px; padding:5px; line-height:50px;" class="form-control" id="newpass" placeholder="Enter The New Password" name="userid" value="'.$userid_update.'"><br><br><input type="password" style="width:300px; height:50px; padding:5px; line-height:50px;" class="form-control" id="renewpass" placeholder="Reenter The New Passoword" name="repass"><br><br><center><img src="all_icons/loading.gif" width="120" height="120" style="display:none;" id="working_recover_email1"><button class="ui-button" type="submit" id="checktoken" style="width:150px; height:40px; background:white;">RECOVER NOW!!</button></center>
</div><br><br><strong>*IF PAGE REDIRECT TO WWW.ASGASMUSIC.COM. IT MEAN PASSWORD UPDATED.</strong> </center></form>'; 
			  }
			else
			  {
				  echo "Please Reset Your Password With Correct Link";
			  }
		
  }
?>


