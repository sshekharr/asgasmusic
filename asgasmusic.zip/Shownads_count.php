<?php
session_start();
if(isset($_SESSION['userid'])&&isset($_POST['userid'])&&isset($_POST['count'])&&isset($_POST['date']))
   {
	   if($_POST['count']<=10)
	   {
		   include("db.php");
	   $str_date__=$_POST['date'];
	   $ads_id=$_POST['count'];
	   $userid=$_POST['userid'];
	   $insert="INSERT INTO `user-shown-ads`(`userid`, `date`, `ads-id`) VALUES ('$userid','$str_date__','$ads_id')";
	   $query_insert=mysqli_query($conn,$insert);
	   }
   }
?>