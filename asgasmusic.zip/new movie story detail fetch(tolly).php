<?php
 include('db.php');
$sql="SELECT * FROM `movie-ditails` WHERE `type`='Tollywood' ORDER BY `id` DESC LIMIT 1";
$query1=mysqli_query($conn,$sql);
$count=mysqli_num_rows($query1);
while($fetch_movie=mysqli_fetch_assoc($query1))
		  {
			  
			  $director=$fetch_movie['director'];
			  $moviename=$fetch_movie['movie-name'];
			  $producer=$fetch_movie['producer'];
			  $writer=$fetch_movie['writer'];
			  $music_director=$fetch_movie['music-director'];
			  $star=$fetch_movie['star'];
			  $movie_story=$fetch_movie['movie-story'];
			  $release_date=$fetch_movie['releas-date'];
			  $sql_fetch_pic="SELECT * FROM `albumart_&_details` WHERE `moviename`='$moviename'";
			  $query=mysqli_query($conn,$sql_fetch_pic);
			  $fetch_pic=mysqli_fetch_assoc($query);
			  $pic=$fetch_pic['address'];
			  echo '<!--INFOLINKS_ON--><div class="latest_movie_story bengali"><!--start of the movie story div -->
	<div class="song-content-header margin"><!--start of the movie story div header-->
	About Upcoming Movie
	</div><!--End of the movie story div header-->
	<div class="movie_poster"><!--start of the movie story div poster-->
	<img src="'.$pic.'" class="poster_size">	
	</div><!--End of the movie story div poster-->
	<div class="details_contain"><!--start of the movie story details-->
	<div class="movie_detail bottom">
	<div class="movie_detail_art">
		<div class="move_left">
		<strong><u>Starring</u>:-</strong><div class="inline">'.$star.'</div><br><br>
		<strong><u>Director</u>:-</strong><div class="inline"> '.$director.'</div> <br><br>
		<strong><u>Writers</u>:-</strong> <div class="inline">'.$writer.'</div> <br><br>
		</div>
	</div>
	<div class="movie_detail_art">
	<div class="move_left_45">
		<strong><u>Production company</u>:-</strong><div class="inline"> '.$producer.'</div> <br><br>
		<strong><u>Music director</u>:-</strong><div class="inline"> '.$music_director.'</div> <br><br>
		<strong><u>Release date</u>:-</strong><div class="inline">'.$release_date.'</div>
		</div>
	</div>
	</div><input type="hidden" name="IL_IN_ARTICLE">
     	'.$movie_story.'
</div><!--End of the movie story details-->
</div><!--End of the movie story div --><!--INFOLINKS_OFF-->';
		  }
?>