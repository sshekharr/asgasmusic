<?php
echo(strtotime(date('y-m-d')));
?>